#requires -Version 5.1
[CmdletBinding()]
param([switch]$CollectOnly,[string]$MsiPath,[string]$OutputDirectory,[switch]$FunctionsOnly)
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'
$script:ExpectedMsiHash='89635F4EA5CD120B247003AF356E15EC80EBA89AFBB04081064331300F5A439B'
$script:Warnings=New-Object 'Collections.Generic.List[string]'
function Redact([string]$Text){
    $Text=[regex]::Replace($Text,'(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{43}=(?![A-Za-z0-9+/=])','[WireGuard-sized key redacted]')
    $Text=[regex]::Replace($Text,'(?i)\bBearer\s+[^\s"'']+','Bearer [redacted]')
    $Text=[regex]::Replace($Text,'(?im)("?(?:private[_ -]?key|password|api[_ -]?token|access[_ -]?token|authorization|secret)"?\s*[:=]\s*)("[^"\r\n]*"|''[^''\r\n]*''|[^\s,}\r\n]+)','$1[redacted]')
    $Text=[regex]::Replace($Text,'(?im)(\b(?:PASSWORD|PRIVATEKEY|API_TOKEN|ACCESS_TOKEN|SECRET|AUTHORIZATION)\b[^\r\n]*?value is\s*)''[^''\r\n]*''','$1''[redacted]''')
    return $Text
}
function Read-SafeText([string]$Path,[long]$Limit=16777216){
    $file=Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if($file -isnot [IO.FileInfo] -or $file.Length -gt $Limit){throw 'Diagnostic file is missing, not a regular file, or exceeds the size limit.'}
    $node=$file
    while($node){if($node.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'A diagnostic path contains a link; its target was not read.'};$node=if($node -is [IO.FileInfo]){$node.Directory}else{$node.Parent}}
    return [IO.File]::ReadAllText($file.FullName)
}
function Is-WhisprLog([string]$Text){return $Text -match '(?i)whispr Hybrid VPN|WhisprPrepare|WhisprFinalize|WhisprRollback|WhisprCommit|21A8F5D7-2682-45C8-B2DE-92C9D8699A11'}
function Quote-Argument([string]$Text){return '"'+[regex]::Replace($Text,'(\\*)"','$1$1\"').TrimEnd([char]'\')+('\'*(2*([regex]::Match($Text,'\\*$').Length)))+'"'}
function Failure-Excerpt([string]$Text){
    $lines=@($Text -split '\r?\n');$indices=New-Object 'Collections.Generic.HashSet[int]'
    for($i=0;$i -lt $lines.Count;$i++){
        if($lines[$i] -match '(?i)Return value 3|whispr MSI .+ failed:|Client maintenance could not finish|Cannot stage the embedded|Maintenance timed out|engine validation failed|error (1603|1722|1723)'){
            for($j=[Math]::Max(0,$i-45);$j -le [Math]::Min($lines.Count-1,$i+15);$j++){[void]$indices.Add($j)}
        }
    }
    return Redact ((@($indices|Sort-Object|Select-Object -First 1500|ForEach-Object {([string]($_+1))+': '+$lines[$_]})) -join [Environment]::NewLine)
}
function Write-ShareText([string]$Name,[string]$Text){[IO.File]::WriteAllText((Join-Path $script:Share $Name),(Redact $Text),[Text.UTF8Encoding]::new($false))}
function Warning([string]$Text){$script:Warnings.Add((Redact $Text));Write-Host ('NOTE: '+$Text) -ForegroundColor Yellow}
function Collect-Journals([string]$Prefix){
    $data=[Environment]::GetFolderPath('CommonApplicationData')
    foreach($root in @((Join-Path $data 'whispr-hybrid-msi'),(Join-Path $data 'whispr-vpn-setup/logs'))){
        if(-not(Test-Path -LiteralPath $root)){continue}
        try{
            $dirs=@(Get-ChildItem -LiteralPath $root -Directory -Force|Where-Object {$_.Name -match '^[a-fA-F0-9]{32}$'}|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 8)
            $number=0
            foreach($dir in $dirs){
                $number++
                foreach($name in @('setup.log','status.txt','engine-check.err','engine-check.out','powershell.log','error.txt')){
                    $file=Join-Path $dir.FullName $name;if(-not(Test-Path -LiteralPath $file)){continue}
                    try{$text=Read-SafeText $file;Write-ShareText ($Prefix+'-'+[IO.Path]::GetFileName($root)+'-'+$number+'-'+$name) ($file+"`r`n"+$text)}catch{Warning ('Could not read '+$name+': '+$_.Exception.Message)}
                }
                $file=Join-Path $dir.FullName 'journal.json'
                if(Test-Path -LiteralPath $file){
                    try{
                        $record=Read-SafeText $file|ConvertFrom-Json;$summary=@{Source=$file}
                        foreach($field in @('Product','Schema','Transaction','Operation','Prepared','coreExisted','stateExisted','Phase','MsiExitCode')){
                            $property=$record.PSObject.Properties[$field]
                            if($property -and ($property.Value -is [string] -or $property.Value -is [ValueType])){$summary[$field]=([string]$property.Value).Substring(0,[Math]::Min(150,([string]$property.Value).Length))}
                        }
                        Write-ShareText ($Prefix+'-journal-'+$number+'.json') ($summary|ConvertTo-Json -Depth 3)
                    }catch{Warning ('Could not summarize a transaction journal: '+$_.Exception.Message)}
                }
            }
        }catch{Warning ('Could not enumerate '+$root+': '+$_.Exception.Message)}
    }
}
function Collect-RecentMsiLogs {
    $seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase);$saved=0
    foreach($root in @([IO.Path]::GetTempPath(),(Join-Path $env:SystemRoot 'Temp'))|Select-Object -Unique){
        try{
            foreach($file in @(Get-ChildItem -LiteralPath $root -Filter '*.log' -File -Force -ErrorAction Stop|Where-Object {$_.LastWriteTimeUtc -gt [DateTime]::UtcNow.AddDays(-2) -and ($_.Name -like 'MSI*.log' -or $_.Name -like '*whispr*.log')}|Sort-Object LastWriteTimeUtc -Descending|Select-Object -First 20)){
                if($saved -ge 3){return};if(-not $seen.Add($file.FullName)){continue}
                try{$text=Read-SafeText $file.FullName;if(-not(Is-WhisprLog $text)){continue};$saved++;Write-ShareText ('existing-msi-'+$saved+'.log') ($file.FullName+"`r`n"+$text);Write-ShareText ('existing-msi-'+$saved+'-errors.txt') (Failure-Excerpt $text)}catch{}
            }
        }catch{Warning ('Cannot inspect log directory '+$root)}
    }
}
function Collect-Context {
    $data=[Environment]::GetFolderPath('CommonApplicationData');$programs=[Environment]::GetFolderPath('ProgramFiles')
    $rows=New-Object 'Collections.Generic.List[object]'
    foreach($path in @((Join-Path $data 'whispr-hybrid'),(Join-Path $data 'whispr-hybrid-msi'),(Join-Path $programs 'whispr Hybrid VPN'),(Join-Path $programs 'whispr VPN'))){
        $row=[ordered]@{Path=$path;Exists=(Test-Path -LiteralPath $path)}
        if($row.Exists){try{$item=Get-Item -LiteralPath $path -Force;$row.IsReparsePoint=[bool]($item.Attributes -band [IO.FileAttributes]::ReparsePoint);$row.Owner=(Get-Acl -LiteralPath $path).Owner}catch{$row.ReadError=$_.Exception.Message}}
        $rows.Add([pscustomobject]$row)
    }
    $context=[ordered]@{CreatedUtc=[DateTime]::UtcNow.ToString('o');WindowsVersion=[Environment]::OSVersion.Version.ToString();Is64Bit=[Environment]::Is64BitProcess;PowerShellVersion=$PSVersionTable.PSVersion.ToString();Folders=$rows.ToArray()}
    Write-ShareText 'context.json' ($context|ConvertTo-Json -Depth 5)
    try{
        $services=@(Get-Service -Name BFE,MpsSvc,msiserver,Schedule -ErrorAction SilentlyContinue|Select-Object Name,Status)
        Write-ShareText 'services.json' ($services|ConvertTo-Json -Depth 3)
    }catch{Warning 'Could not read service status.'}
    try{
        $events=@(Get-WinEvent -FilterHashtable @{LogName='Application';ProviderName='MsiInstaller';StartTime=(Get-Date).AddDays(-2)} -MaxEvents 80 -ErrorAction Stop|Where-Object {$_.Message -match '(?i)whispr|21A8F5D7-2682-45C8-B2DE-92C9D8699A11'}|Select-Object TimeCreated,Id,LevelDisplayName,Message)
        Write-ShareText 'installer-events.json' ($events|ConvertTo-Json -Depth 4)
    }catch{Warning 'No readable matching Windows Installer events were found.'}
}
function Find-Installer([string]$ExplicitPath){
    if($ExplicitPath){$candidates=@(Get-Item -LiteralPath $ExplicitPath -ErrorAction Stop)}else{
        $roots=@($PSScriptRoot,(Split-Path $PSScriptRoot -Parent),(Split-Path (Split-Path $PSScriptRoot -Parent) -Parent),(Join-Path $env:USERPROFILE 'Downloads'))
        try{$key=Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders';$value=$key.PSObject.Properties['{374DE290-123F-4565-9164-39C4925E467B}'];if($value){$roots+=[Environment]::ExpandEnvironmentVariables([string]$value.Value)}}catch{}
        $candidates=@(foreach($root in $roots|Select-Object -Unique){if(Test-Path -LiteralPath $root){Get-ChildItem -LiteralPath $root -File -Filter 'whispr-hybrid-vpn-1.1.0*.msi' -ErrorAction SilentlyContinue}})|Sort-Object LastWriteTimeUtc -Descending
    }
    foreach($file in $candidates){if($file -is [IO.FileInfo] -and -not($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -and (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash -ieq $script:ExpectedMsiHash){return $file.FullName}}
    throw 'The corrected UI fix1 MSI was not found. Put whispr-hybrid-vpn-1.1.0-x64.msi beside RUN-INSTALL-WITH-LOG.cmd, then run it again. The old defective MSI will not be launched.'
}
function Build-ShareArchive([string]$Directory,[string]$Zip){
    [void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
    [IO.Compression.ZipFile]::CreateFromDirectory($Directory,$Zip,[IO.Compression.CompressionLevel]::Optimal,$false)
}
if($FunctionsOnly){return}
$result=1
try{
    if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or -not [Environment]::Is64BitProcess){throw 'Use the supplied launcher on 64-bit Windows.'}
    if(-not $OutputDirectory){$OutputDirectory=Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) ('whispr-install-diagnostics-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))}
    if(-not $CollectOnly -and -not $MsiPath){try{$MsiPath=Find-Installer ''}catch{Write-Host $_.Exception.Message -ForegroundColor Yellow}}
    $who=[Security.Principal.WindowsIdentity]::GetCurrent()
    if(-not([Security.Principal.WindowsPrincipal]::new($who)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
        $arguments='-NoLogo -NoProfile -ExecutionPolicy Bypass -File '+(Quote-Argument $PSCommandPath)+' -OutputDirectory '+(Quote-Argument $OutputDirectory)
        if($CollectOnly){$arguments+=' -CollectOnly'};if($MsiPath){$arguments+=' -MsiPath '+(Quote-Argument $MsiPath)}
        $p=Start-Process -FilePath "$env:SystemRoot/System32/WindowsPowerShell/v1.0/powershell.exe" -Verb RunAs -ArgumentList $arguments -PassThru -Wait
        exit $p.ExitCode
    }
    if(Test-Path -LiteralPath $OutputDirectory){throw 'The diagnostic output directory already exists; it was not overwritten.'}
    [void][IO.Directory]::CreateDirectory($OutputDirectory);$script:Share=Join-Path $OutputDirectory 'SHARE-THIS';[void][IO.Directory]::CreateDirectory($script:Share)
    Write-Host 'Saving existing installer evidence first. No cleanup, firewall reset or key files are included.' -ForegroundColor Cyan
    Collect-Journals 'before';Collect-RecentMsiLogs;Collect-Context
    if(-not $CollectOnly){
        try{
            $MsiPath=Find-Installer $MsiPath
            # Use local TEMP rather than a potentially OneDrive-backed Desktop for the raw MSI log.
            $private=Join-Path ([IO.Path]::GetTempPath()) ('whispr-install-private-'+[guid]::NewGuid().ToString('N'))
            [void][IO.Directory]::CreateDirectory($private);$raw=Join-Path $private 'PRIVATE-raw-msi.log'
            Write-Host 'The same corrected MSI will now open with verbose logging. Repeat the install, then close its final window.' -ForegroundColor Yellow
            $args='/i '+(Quote-Argument $MsiPath)+' /norestart REBOOT=ReallySuppress /L*vx! '+(Quote-Argument $raw)
            $p=Start-Process -FilePath "$env:SystemRoot/System32/msiexec.exe" -ArgumentList $args -PassThru
            try{$p.WaitForExit();$code=$p.ExitCode}finally{$p.Dispose()}
            Write-ShareText 'attempt.json' (@{MsiFile=$MsiPath;Sha256=$script:ExpectedMsiHash;ExitCode=$code;RecordedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json)
            if(Test-Path -LiteralPath $raw){$text=Read-SafeText $raw 67108864;Write-ShareText 'new-msi.log' $text;Write-ShareText 'new-msi-errors.txt' (Failure-Excerpt $text)}
            else{Warning 'Windows Installer did not produce the requested log.'}
        }catch{Warning $_.Exception.Message}
        Collect-Journals 'after';Collect-Context
    }
    Write-ShareText 'README.txt' "Share only the ZIP beside this folder. It contains selected installer logs and context, with common secret/key patterns redacted. Device-key.json, peer.json, engine.json, saved profiles and raw journal/task data are not copied. The PRIVATE-raw-msi.log file in a separate local TEMP folder is not in the ZIP. Review redacted logs if you have unusual credentials in installer properties."
    Write-ShareText 'collector-notes.txt' ($script:Warnings.ToArray() -join [Environment]::NewLine)
    $zip=$OutputDirectory+'-SHARE-THIS.zip';Build-ShareArchive $script:Share $zip
    Write-Host "`nATTACH THIS FILE IN CHAT:`n$zip" -ForegroundColor Green
    Write-Host 'The report does not claim the installation is fixed. It captures the underlying failure.'
    $result=0
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;if($OutputDirectory){Write-Host ('Any captured evidence remains in '+$OutputDirectory)}}
exit $result
