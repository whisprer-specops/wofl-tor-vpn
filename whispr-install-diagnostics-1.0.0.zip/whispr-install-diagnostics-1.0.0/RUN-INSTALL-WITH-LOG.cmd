@echo off
setlocal
cd /d "%~dp0"
set "WHISPR_DIAG_HOST=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "WHISPR_DIAG_HOST=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%WHISPR_DIAG_HOST%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Capture-InstallFailure.ps1"
set "WHISPR_DIAG_RESULT=%ERRORLEVEL%"
echo.
echo The SHARE-THIS.zip report is saved on your Desktop.
echo If a log capture failed, read the message above before retrying.
pause
exit /b %WHISPR_DIAG_RESULT%
