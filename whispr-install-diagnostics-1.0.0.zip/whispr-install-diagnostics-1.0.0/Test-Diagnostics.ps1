#requires -Version 7.0
$ErrorActionPreference='Stop'
$file=Join-Path $PSScriptRoot 'Capture-InstallFailure.ps1';$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($file,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors.Message -join '; ')}
. $file -FunctionsOnly
$count=0
function Check($value,$message){if(-not $value){throw $message};$script:count++}
$key=('A'*43)+'='
foreach($text in @('PrivateKey='+$key,'"private_key": "'+$key+'"','private key: '+$key)){
    $safe=Redact $text;Check (-not $safe.Contains($key)) 'WireGuard-shaped private key leaked'
}
foreach($text in @('password=secret-value','"password": "a secret with spaces"',"PASSWORD property. Its value is 'secret-value'",'Authorization: Bearer abc-def-ghi')){
    $safe=Redact $text;Check ($safe -notmatch 'secret-value|a secret with spaces|abc-def-ghi') 'Common credential syntax leaked'
}
Check (Is-WhisprLog 'Action ended 00:00: WhisprPrepare. Return value 3.') 'Own installer log rejected'
Check (-not(Is-WhisprLog 'Product: Microsoft Visual C++ Runtime')) 'Unrelated MSI log accepted'
$sample=(1..70|ForEach-Object {'line '+$_}) -join "`n"
$sample+="`nwhispr MSI Prepare failed: useful underlying exception`nAction ended: WhisprPrepare. Return value 3.`nRollback begins"
$excerpt=Failure-Excerpt $sample
Check ($excerpt -match 'useful underlying exception' -and $excerpt -match 'WhisprPrepare') 'Underlying failure/context missing'
$dir=Join-Path ([IO.Path]::GetTempPath()) ('whispr-diag-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($dir)
try{
    $path=Join-Path $dir 'sample.log';[IO.File]::WriteAllText($path,'whispr: useful UTF-8 text')
    Check ((Read-SafeText $path) -match 'useful UTF-8') 'UTF-8 file reading failed'
    [IO.File]::WriteAllText($path,'whispr: UTF-16 text',[Text.Encoding]::Unicode)
    Check ((Read-SafeText $path) -match 'UTF-16 text') 'UTF-16 MSI log reading failed'
    $blocked=$false;try{Read-SafeText $path 1|Out-Null}catch{$blocked=$true};Check $blocked 'Size limit ignored'
    if(-not $IsWindows){
        [void](New-Item -ItemType SymbolicLink -Path (Join-Path $dir 'link.log') -Target $path)
        $blocked=$false;try{Read-SafeText (Join-Path $dir 'link.log')|Out-Null}catch{$blocked=$true};Check $blocked 'Link target was read'
    }
    $fake=Join-Path $dir 'package.msi';[IO.File]::WriteAllText($fake,'synthetic test input, never executable')
    $script:ExpectedMsiHash=(Get-FileHash -LiteralPath $fake).Hash
    Check ((Find-Installer $fake) -eq $fake) 'Pinned explicit installer selection failed'
    $script:ExpectedMsiHash='0'*64;$blocked=$false;try{Find-Installer $fake|Out-Null}catch{$blocked=$true};Check $blocked 'Wrong installer hash accepted'
    $script:Share=Join-Path $dir 'SHARE-THIS';[void][IO.Directory]::CreateDirectory($script:Share)
    Write-ShareText 'safe.log' ('password=secret-value '+$key)
    [IO.File]::WriteAllText((Join-Path $dir 'PRIVATE-raw-msi.log'),'RAW PRIVATE SENTINEL')
    $zip=Join-Path $dir 'share.zip';Build-ShareArchive $script:Share $zip
    $z=[IO.Compression.ZipFile]::OpenRead($zip)
    try{
        Check ($z.Entries.Count -eq 1 -and $z.Entries[0].FullName -eq 'safe.log') 'Private raw file was included in the ZIP'
        $reader=[IO.StreamReader]::new($z.Entries[0].Open())
        try{$text=$reader.ReadToEnd();Check ($text -notmatch 'secret-value|RAW PRIVATE SENTINEL' -and -not $text.Contains($key)) 'Share ZIP contains unredacted fixture secrets'}finally{$reader.Dispose()}
    }finally{$z.Dispose()}
    $commands=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst]},$true)|ForEach-Object {$_.GetCommandName()})
    Check (-not @($commands|Where-Object {$_ -match '^(?:Stop-Process|Stop-Service|Remove-NetFirewallRule|Remove-NetRoute|Remove-NetAdapter|Invoke-Expression|Add-Type)$'}).Count) 'Collector contains a cleanup/compiler action'
    Write-Host ('PASS: '+$count+' diagnostic assertions; Windows installer execution was not performed.')
}finally{Remove-Item -LiteralPath $dir -Recurse -Force}
