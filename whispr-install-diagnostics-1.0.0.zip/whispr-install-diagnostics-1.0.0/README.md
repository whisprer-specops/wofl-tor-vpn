# whispr installer failure capture 1.0.0

The screenshot's "Client maintenance could not finish" text is emitted by a shared
handler for Prepare, Finalize, Rollback and Commit. It does not identify which one
failed or why. This tool gathers that evidence without guessing another fix.

1. Extract this ZIP completely. Keep the corrected UI fix1 MSI in Downloads, or put
   it beside `RUN-INSTALL-WITH-LOG.cmd` in this folder.
2. Close the failed installer windows. Double-click **RUN-INSTALL-WITH-LOG.cmd** and
   approve administrator access. Existing evidence is saved before the new attempt.
3. The same MSI opens with verbose, flushed logging. Repeat the install normally.
   Close its final success/failure window and let the capture window finish.
4. Attach the **whispr-install-diagnostics-...-SHARE-THIS.zip** created on your Desktop.

The tool accepts only the corrected UI fix1 MSI, identified by SHA-256:

```text
89635f4ea5cd120b247003af356e15ec80eba89afbb04081064331300f5a439b
```

It does not download or alter the MSI. Re-running the MSI is a normal install attempt
and can execute that installer's maintenance actions; it is not a read-only operation.
It does not silently accept the license, bypass a failing action, change permanent
logging policy or run the hard reset. The capture script itself does not stop
processes, delete application state, change firewall policy, or repair Windows.

For collection without another install attempt, use **COLLECT-EXISTING-ONLY.cmd**.
That option may have insufficient detail if the original double-click had no MSI
logging enabled. Both launchers use built-in 64-bit Windows PowerShell 5.1, so the
packaged PowerShell 7 runtime is not required to capture evidence.

The share ZIP includes selected/redacted installer logs and failure excerpts,
transaction status, a small journal metadata summary, app folder existence/owner
information, relevant service status and matching Windows Installer events. The
before/after snapshots can preserve an error that rollback subsequently removes.

The tool does **not** copy `device-key.json`, `peer.json`, `engine.json`, saved
profiles, full task XML, full journal contents, source trees or installed binaries.
WireGuard-sized keys and common password/token formats are redacted. Unrelated
MSI logs are excluded by a whispr-specific marker check. Files over configured
limits or paths through junctions/symlinks are skipped and noted.

The local `PRIVATE-raw-msi.log` is in a separate randomly named local TEMP folder,
outside the `SHARE-THIS` folder and outside the share ZIP. This also avoids using
a OneDrive Desktop as the raw logging destination. Share the ZIP, not raw logs. Redaction cannot
guarantee every possible custom credential format; review the share text if you
have deliberately placed unusual secrets in installer properties.

The diagnostic report is not a claim that setup succeeded or that its root cause
has been corrected. Its purpose is to identify the failing action and original
error before another installer change. Do not repeat cleanup first; that may erase
useful records. Missing journals are reported as missing evidence, not proof of
success or proof that cleanup failed.

`Test-Diagnostics.ps1` checks parsing, log ownership selection, redaction, UTF-8/
UTF-16 reading, limits/link refusal, pinned MSI selection, error excerpts, and ZIP
exclusion of a raw private fixture. Tests run with PowerShell 7 on Linux; native
Windows PowerShell 5.1 and MSI execution are not certified in this environment.

Microsoft logging reference:
https://learn.microsoft.com/en-us/windows/win32/msi/command-line-options
