#requires -Version 7.2
param([string]$Reference=(Join-Path $PSScriptRoot 'reference/mscorlib.dll'))
$ErrorActionPreference='Stop'
[void][Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll'))
[void][Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll'))
$source=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Native.cs'))
$tree=[Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($source)
$referenceAssembly=[Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile([IO.Path]::GetFullPath($Reference))
$options=[Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::DynamicallyLinkedLibrary)
$options=$options.WithOptimizationLevel([Microsoft.CodeAnalysis.OptimizationLevel]::Release).WithDeterministic($true)
$compilation=[Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('Whispr.Setup.Native',[Microsoft.CodeAnalysis.SyntaxTree[]]@($tree),[Microsoft.CodeAnalysis.MetadataReference[]]@($referenceAssembly),$options)
$output=Join-Path $PSScriptRoot 'bin/Whispr.Setup.Native.dll'
[void][IO.Directory]::CreateDirectory((Split-Path $output -Parent))
$stream=[IO.File]::Create($output)
try{$result=$compilation.Emit($stream)}finally{$stream.Dispose()}
if(-not $result.Success){$result.Diagnostics|ForEach-Object {Write-Host $_.ToString()};throw 'Precompiling the NET Framework helper failed'}
$assembly=[Reflection.Assembly]::LoadFile($output)
$refs=@($assembly.GetReferencedAssemblies())
if($refs.Count -ne 1 -or $refs[0].Name -cne 'mscorlib' -or $refs[0].Version.ToString() -cne '4.0.0.0'){throw 'Helper does not target the Windows PowerShell/.NET Framework runtime'}
Write-Host ('BUILT: precompiled .NET Framework helper; references only mscorlib 4.0.0.0; SHA256 '+(Get-FileHash $output).Hash)
