#requires -Version 5.1
[CmdletBinding()]
param([string]$PackageRoot,[string]$JournalRoot,[string]$ExpectedMsiHash,[string]$ExpectedNativeHash,[switch]$LibraryOnly)
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'
$script:GuardHash='44863A7FAF76F8877681283F6A16E4CB02A3C051117439345C469364A4306EA6'
$programRoot=if($LibraryOnly){$env:ProgramFiles}else{[Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFiles)}
$commonRoot=if($LibraryOnly){$env:ProgramData}else{[Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)}
$script:Core=Join-Path $programRoot 'whispr Hybrid VPN'
$script:Suite=Join-Path $programRoot 'whispr VPN'
$script:State=Join-Path $commonRoot 'whispr-hybrid'
$script:HeldLocks=New-Object 'Collections.Generic.List[object]'
function Field($Object,[string]$Name){if($null -eq $Object){return $null};$p=$Object.PSObject.Properties[$Name];if($p){return $p.Value};return $null}
function Save-Json($Value,[string]$Path){
    $temporary=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try{[IO.File]::WriteAllText($temporary,($Value|ConvertTo-Json -Depth 24),[Text.UTF8Encoding]::new($false));if(Test-Path -LiteralPath $Path){[IO.File]::Replace($temporary,$Path,[NullString]::Value)}else{[IO.File]::Move($temporary,$Path)}}finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force}}
}
function Read-Json([string]$Path){
    $item=Get-Item -LiteralPath $Path -Force
    if($item -isnot [IO.FileInfo] -or $item.Length -gt 2097152 -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Unexpected setup record: '+[IO.Path]::GetFileName($Path)}
    try{return (Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json)}catch{throw 'An expected JSON record is malformed. Its contents were not printed.'}
}
function Note([string]$Text){
    if($JournalRoot){[IO.File]::WriteAllText((Join-Path $JournalRoot 'status.txt'),$Text,[Text.Encoding]::Unicode);Add-Content -LiteralPath (Join-Path $JournalRoot 'setup.log') -Value ((Get-Date -Format o)+' '+$Text) -Encoding UTF8}
}
function Is-Under([string]$Path,[string]$Root){if(-not $Path){return $false};return [IO.Path]::GetFullPath($Path).StartsWith(([IO.Path]::GetFullPath($Root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)}
function Assert-Directory([string]$Path,[switch]$Optional){
    if($Optional -and -not (Test-Path -LiteralPath $Path)){return}
    $item=Get-Item -LiteralPath $Path -Force
    if($item -isnot [IO.DirectoryInfo] -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'A setup/client directory is a file or a link: '+$Path}
    $owner=(Get-Acl -LiteralPath $Path).GetOwner([Security.Principal.SecurityIdentifier]).Value
    if($owner -notin @('S-1-5-18','S-1-5-32-544')){throw 'The expected protected directory has an unrecognised owner: '+$Path}
}
function Assert-Leaf([string]$Path){
    $item=Get-Item -LiteralPath $Path -Force
    if($item -isnot [IO.FileInfo] -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'An expected setup/client file is a link or directory: '+$Path}
}
function Add-SetupNative {
    $path=Join-Path $PackageRoot 'Whispr.Setup.Native.dll'
    Assert-Leaf $path
    if($ExpectedNativeHash -cnotmatch '^[A-Fa-f0-9]{64}$' -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $ExpectedNativeHash){throw 'The precompiled setup helper failed its integrity check'}
    if(-not ('WhisprSetupNative103' -as [type])){[void][Reflection.Assembly]::LoadFrom($path)}
}
function Split-CommandLine([string]$Command){return [WhisprSetupNative103]::Args($Command)}
function Stop-VerifiedProcess($Record){return [WhisprSetupNative103]::Stop([uint32]$Record.ProcessId,[string]$Record.ExecutablePath,([datetime]$Record.CreationDate).ToUniversalTime().ToFileTimeUtc())}
function Connect-TaskScheduler { $service=New-Object -ComObject Schedule.Service;$service.Connect();return $service }
function Assert-SetupAdministrator {
    $build=[int](Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name CurrentBuildNumber -ErrorAction Stop).CurrentBuildNumber
    if($build -lt 22000){throw 'This installer requires Windows 11 x64. No whispr process was stopped.'}
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{if(-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Setup needs Windows administrator approval'}}finally{$identity.Dispose()}
}
function Get-MsiFailureSummary([string]$Log){
    if(-not (Test-Path -LiteralPath $Log)){return ''}
    $matches=@(Select-String -LiteralPath $Log -Pattern 'whispr VPN preflight:|An existing installation needs recovery:|Run whispr-vpn-[0-9.]+-setup[.]exe|Error (1[0-9]{3}|2[0-9]{3})'|Select-Object -Last 3|ForEach-Object {$_.Line.Trim()})
    $text=($matches -join ' ')-replace '[A-Za-z0-9+/]{43}=','[key withheld]'
    return $text.Substring(0,[Math]::Min($text.Length,1200))
}
function Invoke-DesktopMsi([string]$Msi,[string]$Log){
    $arguments=@('/i',('"'+$Msi+'"'),'/norestart','REBOOT=ReallySuppress','LAUNCH_APP=0','WHISPR_SETUP_MANAGED=1','/L*v',('"'+$Log+'"'))
    $child=Start-Process -FilePath (Join-Path ([Environment]::SystemDirectory) 'msiexec.exe') -ArgumentList $arguments -PassThru
    $nextCheck=[DateTime]::UtcNow.AddSeconds(5)
    try{while(-not $child.WaitForExit(1000)){if([DateTime]::UtcNow -ge $nextCheck){try{Stop-OwnProcesses}catch{Note 'A whispr restart attempt could not be stopped; Windows Installer remains in control. The MSI log records its result.'};$nextCheck=[DateTime]::UtcNow.AddSeconds(5)}};return $child.ExitCode}finally{$child.Dispose()}
}
function Test-ScriptArguments([string[]]$Tokens,[string[]]$Expected){
    for($i=0;$i -lt $Tokens.Count;$i++){
        $a=$Tokens[$i]
        if($a -ieq '-File' -or $a -ieq '-f'){return ($i+1 -lt $Tokens.Count -and $Tokens[$i+1] -iin $Expected)}
        if($a -in @('-NoLogo','-NoProfile','-NonInteractive','-STA','-MTA')){continue}
        if($a -in @('-WindowStyle','-ExecutionPolicy')){
            if($i+1 -ge $Tokens.Count){return $false}
            if($a -ieq '-WindowStyle' -and $Tokens[$i+1] -notin @('Normal','Hidden','Minimized','Maximized')){return $false}
            if($a -ieq '-ExecutionPolicy' -and $Tokens[$i+1] -notin @('Restricted','AllSigned','RemoteSigned','Unrestricted','Bypass','Undefined','Default')){return $false}
            $i++;continue
        }
        return $false
    }
    return $false
}
function Get-OwnScripts {
    $names=@('Tray.ps1','Open-Tray.ps1','Start.ps1','Start-Background.ps1','background\Scheduled-Host.ps1','background\Host.ps1','client\Session.ps1','core\Session.ps1','core\Session-console.ps1')
    foreach($name in $names){Join-Path $script:Core $name}
    foreach($name in @('Desktop.ps1','Worker.ps1')){Join-Path $script:Suite $name}
}
function Test-OwnProcess($Record){
    $id=[int](Field $Record 'ProcessId');$exe=[string](Field $Record 'ExecutablePath')
    if(-not $id -or $id -eq $PID -or -not $exe){return $false}
    $name=[IO.Path]::GetFileName($exe)
    if($name -in @('System','Registry','smss.exe','csrss.exe','wininit.exe','services.exe','lsass.exe','winlogon.exe','svchost.exe','dwm.exe','explorer.exe','conhost.exe','WindowsTerminal.exe','cmd.exe','MsMpEng.exe')){return $false}
    $binaries=@((Join-Path $script:Core 'bin\sing-box.exe'),(Join-Path $script:Core 'bin\tor\tor.exe'),(Join-Path $script:Core 'bin\whispr-vpn-guard.exe'),(Join-Path $script:Suite 'runtime\powershell\pwsh.exe'))
    if($exe -iin $binaries){return $true}
    if($name -notin @('pwsh.exe','powershell.exe')){return $false}
    $line=[string](Field $Record 'CommandLine');if(-not $line){return $false}
    $tokens=@(Split-CommandLine $line);if($tokens.Count -lt 2){return $false}
    return (Test-ScriptArguments @($tokens[1..($tokens.Count-1)]) @(Get-OwnScripts))
}
function Assert-OwnedExecutable([string]$Path){
    foreach($root in @($script:Core,$script:Suite)){
        if(Is-Under $Path $root){
            $relative=[IO.Path]::GetFullPath($Path).Substring([IO.Path]::GetFullPath($root).Length).TrimStart('\','/')
            $current=$root
            foreach($part in ($relative -split '[/\\]')){
                $current=Join-Path $current $part;$item=Get-Item -LiteralPath $current -Force
                if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'A whispr executable path contains a link. No target through that link was stopped.'}
            }
        }
    }
}
function Get-ProcessSnapshot {return @(Get-CimInstance -ClassName Win32_Process -Filter "Name='pwsh.exe' OR Name='powershell.exe' OR Name='sing-box.exe' OR Name='tor.exe' OR Name='whispr-vpn-guard.exe'" -OperationTimeoutSec 15)}
function Stop-OwnProcesses {
    $deadline=[DateTime]::UtcNow.AddSeconds(45)
    do{
        $targets=@(Get-ProcessSnapshot|Where-Object {Test-OwnProcess $_})
        if(-not $targets.Count){return}
        foreach($p in $targets){
            Assert-OwnedExecutable ([string]$p.ExecutablePath)
            if(Stop-VerifiedProcess $p){Note ('Stopped verified whispr process '+[string]$p.ProcessId+' ('+[IO.Path]::GetFileName([string]$p.ExecutablePath)+').')}
        }
        Start-Sleep -Milliseconds 150
    }while([DateTime]::UtcNow -lt $deadline)
    throw 'A verified whispr process is repeatedly restarting. Setup has retained the files and recorded the exact whispr identity in setup.log.'
}
function Task-Fingerprint([string]$Xml){
    $doc=[xml]$Xml
    foreach($node in @($doc.SelectNodes('/*[local-name()="Task"]/*[local-name()="RegistrationInfo"]/*[local-name()="Date"]'))){[void]$node.ParentNode.RemoveChild($node)}
    foreach($node in @($doc.SelectNodes('/*[local-name()="Task"]/*[local-name()="Settings"]/*[local-name()="Enabled"]'))){[void]$node.ParentNode.RemoveChild($node)}
    $sha=[Security.Cryptography.SHA256]::Create();try{return [Convert]::ToBase64String($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($doc.OuterXml)))}finally{$sha.Dispose()}
}
function Test-TaskDefinition([string]$Name,$Definition){
    $own=$Name -match '^whispr-HybridVPN-(Background|Autostart)-(S-1-5-[0-9-]+)$'
    if(-not $own){
        foreach($a in $Definition.Actions){if($a.Type -eq 0 -and (Is-Under ([string]$a.Path) $script:Suite)){throw 'An unrelated task uses the bundled runtime. It was left untouched: '+$Name}}
        return $false
    }
    $kind=$Matches[1];$sid=$Matches[2]
    $wantedSource=if($kind -eq 'Background'){'whispr-hybrid-on-demand-v1'}else{'whispr-hybrid-autostart-v1'}
    $wantedScript=Join-Path $script:Core $(if($kind -eq 'Background'){'background\Scheduled-Host.ps1'}else{'Tray.ps1'})
    $wantedWorking=if($kind -eq 'Background'){Join-Path $script:Core 'background'}else{$script:Core}
    $principal=[string]$Definition.Principal.UserId
    if($principal -notmatch '^S-1-'){$principal=[Security.Principal.NTAccount]::new($principal).Translate([Security.Principal.SecurityIdentifier]).Value}
    if($Definition.RegistrationInfo.Source -cne $wantedSource -or $Definition.Actions.Count -ne 1 -or $principal -ine $sid){throw 'A whispr-named task has an unexpected owner/action: '+$Name}
    $a=$Definition.Actions.Item(1)
    if($a.Type -ne 0 -or [IO.Path]::GetFileName([string]$a.Path) -ine 'pwsh.exe' -or [string]$a.WorkingDirectory -ine $wantedWorking){throw 'A whispr-named task has an unexpected executable/working folder: '+$Name}
    $tokens=@(Split-CommandLine ('pwsh.exe '+[string]$a.Arguments))
    if($tokens.Count -lt 2 -or -not (Test-ScriptArguments @($tokens[1..($tokens.Count-1)]) @($wantedScript))){throw 'A whispr-named task has unexpected arguments: '+$Name}
    return $true
}
function Get-OwnTasks($Folder){
    foreach($task in $Folder.GetTasks(1)){if(Test-TaskDefinition ([string]$task.Name) $task.Definition){[pscustomobject]@{Path=[string]$task.Path;Enabled=[bool]$task.Enabled;Fingerprint=(Task-Fingerprint ([string]$task.Xml));Task=$task}}}
    foreach($child in $Folder.GetFolders(0)){Get-OwnTasks $child}
}
function Restore-Tasks($Service,$Records){
    $failures=New-Object 'Collections.Generic.List[string]'
    foreach($record in @($Records)){
        try{
            $full=[string]$record.Path;$cut=$full.LastIndexOf('\');if($cut -lt 0){throw 'Invalid saved task path'}
            $folderPath=if($cut -eq 0){'\'}else{$full.Substring(0,$cut)};$name=$full.Substring($cut+1)
            $task=$Service.GetFolder($folderPath).GetTask($name)
            if(-not (Test-TaskDefinition $name $task.Definition) -or (Task-Fingerprint ([string]$task.Xml)) -cne $record.Fingerprint){throw 'Task definition changed'}
            $task.Enabled=[bool]$record.Enabled
        }catch{$failures.Add([string]$record.Path)}
    }
    if($failures.Count){throw 'Could not restore verified task settings: '+($failures -join ', ')}
}
function Get-OwnServices {
    foreach($record in @(Get-CimInstance Win32_Service -Filter "Name='TorVPN' OR Name='whisprHybridVPN' OR Name='whispr-HybridVPN'" -OperationTimeoutSec 15)){
        $tokens=@(Split-CommandLine ([string]$record.PathName));if(-not $tokens.Count){throw 'A whispr service has no executable path'}
        $exe=$tokens[0];$legacy=Join-Path $programRoot 'TorVPN\torvpn-svc.exe'
        $valid=($record.Name -ceq 'TorVPN' -and $exe -ieq $legacy)
        if(-not $valid -or $record.ServiceType -ne 'Own Process'){if($record.State -ne 'Stopped'){throw 'A whispr-named service has an unverified executable: '+$record.Name};continue}
        Assert-Directory (Split-Path $exe -Parent);Assert-Leaf $exe
        [pscustomobject]@{Name=[string]$record.Name;Path=[string]$record.PathName;StartMode=[string]$record.StartMode;Retired=($record.Name -ceq 'TorVPN')}
    }
}
function Set-ServiceStartup([string]$Name,[string]$Mode){$mapped=switch($Mode){'Auto'{'Automatic'}'Manual'{'Manual'}'Disabled'{'Disabled'}default{throw 'Unknown saved service startup mode'}};Set-Service -Name $Name -StartupType $mapped -ErrorAction Stop}
function Stop-OwnServices($Records){
    foreach($record in @($Records)){
        Set-Service -Name $record.Name -StartupType Disabled -ErrorAction Stop
        $service=Get-Service -Name $record.Name -ErrorAction Stop
        try{if($service.Status -ne 'Stopped'){$service.Stop();$service.WaitForStatus([ServiceProcess.ServiceControllerStatus]::Stopped,[TimeSpan]::FromSeconds(25))}}finally{$service.Dispose()}
        Note ('Stopped verified whispr service '+$record.Name+'.')
    }
}
function Restore-Services($Records,[bool]$Successful){
    foreach($record in @($Records)){
        if($record.Name -notin @('TorVPN','whisprHybridVPN','whispr-HybridVPN')){throw 'A saved service is outside the whispr service family'}
        $matched=@(Get-OwnServices|Where-Object {$_.Name -ceq $record.Name})
        if($matched.Count -ne 1 -or $matched[0].Path -ine $record.Path){throw 'A saved service identity changed: '+$record.Name}
        if($Successful -and $record.Retired){Note ('Retired '+$record.Name+' remains stopped/disabled; its prior startup setting is in the journal.')}else{Set-ServiceStartup $record.Name $record.StartMode}
    }
}
function Invoke-Guard([string]$Command){
    $exe=Join-Path $PackageRoot 'whispr-vpn-guard.exe';$p=[Diagnostics.ProcessStartInfo]::new($exe)
    $p.UseShellExecute=$false;$p.CreateNoWindow=$true;$p.Arguments=$Command;$p.RedirectStandardOutput=$true;$p.RedirectStandardError=$true
    $child=[Diagnostics.Process]::Start($p)
    try{if(-not $child.WaitForExit(10000)){try{$child.Kill()}catch{};throw 'The whispr guard operation timed out'};$output=$child.StandardOutput.ReadToEnd().Trim();if($child.ExitCode -ne 0){throw 'The whispr guard operation failed'};return $output}finally{$child.Dispose()}
}
function Remove-OwnTunnel {
    $adapters=@(Get-NetAdapter -IncludeHidden -ErrorAction Stop|Where-Object {$_.Name -ieq 'whispr-hybrid'})
    if(-not $adapters.Count){return};if($adapters.Count -ne 1){throw 'The whispr tunnel name is ambiguous'}
    $adapter=$adapters[0];$session=$null;$path=Join-Path $script:State 'session.json'
    if(Test-Path -LiteralPath $path){$session=Read-Json $path}
    $expected=([string](Field $session 'TunnelGuid')).Trim('{}');$actual=([string]$adapter.InterfaceGuid).Trim('{}')
    $ips=@(Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -ErrorAction Stop|Select-Object -ExpandProperty IPAddress)
    if(($expected -ine $actual -or -not $expected) -and '172.31.249.1' -notin $ips -and 'fd89:77:71::1' -notin $ips){throw 'The whispr tunnel ownership could not be verified. No other adapter was removed'}
    $devices=@(Get-CimInstance Win32_NetworkAdapter -OperationTimeoutSec 15|Where-Object {$_.GUID -and ([string]$_.GUID).Trim('{}') -ieq $actual})
    if($devices.Count -ne 1 -or -not $devices[0].PNPDeviceID){throw 'The exact whispr tunnel device could not be identified'}
    $p=Start-Process -FilePath (Join-Path ([Environment]::SystemDirectory) 'pnputil.exe') -ArgumentList @('/remove-device',('"'+[string]$devices[0].PNPDeviceID+'"')) -PassThru -Wait -WindowStyle Hidden
    $code=$p.ExitCode;$p.Dispose();if($code -notin @(0,3010)){throw 'The exact whispr tunnel device could not be removed'}
    if($code -eq 3010){throw 'Windows requires a restart to finish removing the owned tunnel device. No driver package was uninstalled'}
    $deadline=[DateTime]::UtcNow.AddSeconds(5)
    do{if(-not @(Get-NetAdapter -IncludeHidden -ErrorAction Stop|Where-Object {$_.Name -ieq 'whispr-hybrid'}).Count){return};Start-Sleep -Milliseconds 250}while([DateTime]::UtcNow -lt $deadline)
    throw 'Windows still reports the owned tunnel device. Setup has not replaced files'
}
function Mark-Disconnected {
    $path=Join-Path $script:State 'session.json'
    if(Test-Path -LiteralPath $path){
        $session=Read-Json $path;Copy-Item -LiteralPath $path -Destination (Join-Path $JournalRoot 'session-before.json')
        $session|Add-Member NoteProperty State 'disconnected' -Force
        $session|Add-Member NoteProperty StoppedBy 'whispr-setup-1.0.3' -Force
        Save-Json $session $path
    }
}
function Enter-SetupLock([string]$Name){
    $m=[Threading.Mutex]::new($false,$Name);$locked=$false
    try{try{$locked=$m.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true};if(-not $locked){throw 'Another whispr operation still owns '+$Name};$script:HeldLocks.Add($m)}catch{$m.Dispose();throw}
}
function Resume-InterruptedJournals($TaskService){
    $parent=Split-Path $JournalRoot -Parent
    foreach($dir in Get-ChildItem -LiteralPath $parent -Directory){
        if($dir.FullName -ieq $JournalRoot -or $dir.Name -cnotmatch '^[a-f0-9]{32}$'){continue}
        Assert-Directory $dir.FullName
        $path=Join-Path $dir.FullName 'journal.json';if(-not (Test-Path -LiteralPath $path)){continue};$old=Read-Json $path
        if((Field $old 'Product') -cne 'whispr-vpn-setup' -or (Field $old 'Schema') -ne 1){continue}
        if((Field $old 'Phase') -in @('prepared','stopping','installing','restoring')){
            Note 'Restoring startup settings from an interrupted whispr setup attempt.'
            Restore-Tasks $TaskService @($old.Tasks);Restore-Services @($old.Services) $false
            $old.Phase='interrupted-settings-restored';Save-Json $old $path
        }
    }
}
function Invoke-Setup {
    Assert-SetupAdministrator
    if(-not [Environment]::Is64BitProcess){throw 'Use the x64 whispr setup launcher'}
    Assert-Directory $PackageRoot;Assert-Directory $JournalRoot
    foreach($root in @($script:Core,$script:Suite,$script:State)){Assert-Directory $root -Optional}
    $msi=Join-Path $PackageRoot 'whispr-vpn-1.0.2-x64.msi';$guard=Join-Path $PackageRoot 'whispr-vpn-guard.exe'
    Assert-Leaf $msi;Assert-Leaf $guard
    if($ExpectedMsiHash -cnotmatch '^[A-Fa-f0-9]{64}$' -or (Get-FileHash -LiteralPath $msi).Hash -ine $ExpectedMsiHash -or (Get-FileHash -LiteralPath $guard).Hash -cne $script:GuardHash){throw 'The packaged installer/recovery guard failed integrity checks'}
    Add-SetupNative;Enter-SetupLock 'Global\whisprVpnSetup'
    $service=Connect-TaskScheduler;$record=$null;$paused=$false;$success=$false;$exitCode=1
    try{
        Resume-InterruptedJournals $service
        Note 'Identifying whispr tasks, services and processes. Keys and endpoint profiles are retained.'
        $tasks=@(Get-OwnTasks ($service.GetFolder('\')));$services=@(Get-OwnServices)
        $saved=@($tasks|ForEach-Object {[pscustomobject]@{Path=$_.Path;Enabled=$_.Enabled;Fingerprint=$_.Fingerprint}})
        $record=[pscustomobject]@{Product='whispr-vpn-setup';Schema=1;Version='1.0.3';Phase='prepared';Tasks=$saved;Services=$services;StartedUtc=[DateTime]::UtcNow.ToString('o');MsiExitCode=$null}
        Save-Json $record (Join-Path $JournalRoot 'journal.json');$paused=$true;$record.Phase='stopping';Save-Json $record (Join-Path $JournalRoot 'journal.json')
        Note 'Pausing verified whispr startup tasks and stopping its session.'
        foreach($task in $tasks){$task.Task.Enabled=$false;try{$task.Task.Stop(0)}catch{if($task.Task.State -eq 4){throw}}}
        Stop-OwnServices $services;Stop-OwnProcesses
        Note 'Recovering only whispr protection and its owned tunnel.'
        try{Remove-OwnTunnel}finally{[void](Invoke-Guard 'recover')}
        if((Invoke-Guard 'status') -cne 'DISARMED'){throw 'Whispr protection recovery was not confirmed'}
        Mark-Disconnected
        foreach($name in @('Global\whisprHybridVpn040','Global\whisprHybridTray010','Global\whisprHybridBackground011')){Enter-SetupLock $name}
        Stop-OwnProcesses
        $record.Phase='installing';Save-Json $record (Join-Path $JournalRoot 'journal.json')
        Note 'Whispr is stopped. Windows Installer is now installing/repairing the desktop.'
        $log=Join-Path $JournalRoot 'msi-install.log'
        $exitCode=Invoke-DesktopMsi $msi $log
        $record.MsiExitCode=$exitCode;$success=$exitCode -in @(0,3010)
        if(-not $success){if($exitCode -eq 1602){throw 'Installation was cancelled. Whispr startup settings will be restored.'};throw ('Windows Installer returned '+$exitCode+'. '+(Get-MsiFailureSummary $log)+' The detailed log is in this setup journal.')}
    }finally{
        try{
            if($paused){
                $record.Phase='restoring';Save-Json $record (Join-Path $JournalRoot 'journal.json')
                Note 'Restoring the previous whispr startup preference. The VPN remains disconnected.'
                Restore-Tasks $service @($record.Tasks);Restore-Services @($record.Services) $success
                $record.Phase=if($success){'complete'}else{'failed-settings-restored'};Save-Json $record (Join-Path $JournalRoot 'journal.json')
            }
        }finally{foreach($m in $script:HeldLocks){try{$m.ReleaseMutex()}finally{$m.Dispose()}};$script:HeldLocks.Clear();if([Runtime.InteropServices.Marshal]::IsComObject($service)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($service)}}
    }
    Note $(if($exitCode -eq 3010){'Installed. Windows requests a restart. Keys, exits and startup settings were retained.'}else{'Installed. Keys, exits and startup settings were retained. Open whispr VPN from Start to reconnect.'})
    return $exitCode
}
if(-not $LibraryOnly){
    try{$result=Invoke-Setup;exit $result}catch{Note ('SETUP STOPPED: '+$_.Exception.Message);[IO.File]::WriteAllText((Join-Path $JournalRoot 'error.txt'),$_.Exception.Message,[Text.Encoding]::Unicode);exit 1}
}
