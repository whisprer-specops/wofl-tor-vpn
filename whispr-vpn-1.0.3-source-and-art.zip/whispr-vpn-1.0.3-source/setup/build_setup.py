#!/usr/bin/env python3
"""Embed the validated MSI, cleanup script and original guard in a single x64 setup EXE."""
import hashlib,json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=r/'setup';m=r/'dist/whispr-vpn-1.0.2-x64.msi'
report=json.loads((r/'dist/VERIFICATION.json').read_text());digest=hashlib.sha256(m.read_bytes()).hexdigest()
assert digest==report['msi_sha256'] and report['result']=='PASS'
native=s/'bin/Whispr.Setup.Native.dll'
assert native.is_file(), 'Run setup/build_native.ps1 before building setup'
native_digest=hashlib.sha256(native.read_bytes()).hexdigest()
(s/'package_hash.h').write_text('#define MSI_SHA256 L"'+digest+'"\n#define NATIVE_SHA256 L"'+native_digest+'"\n')
def rcpath(p):return str(p.resolve()).replace('\\','/')
resources=[(1,'RT_MANIFEST',s/'launcher.manifest'),(101,'ICON',r/'payload/assets/whispr-vpn.ico'),(201,'RCDATA',m),(202,'RCDATA',s/'Setup.ps1'),(203,'RCDATA',r/'packs/friend/app/bin/whispr-vpn-guard.exe'),(204,'RCDATA',native)]
# RC manifest uses numeric type 24 so Windows honours the requested execution level.
text='\n'.join(f'{i} {"24" if t=="RT_MANIFEST" else t} "{rcpath(p)}"' for i,t,p in resources)+'\n'
text+="""
1 VERSIONINFO
FILEVERSION 1,0,3,0
PRODUCTVERSION 1,0,3,0
FILEFLAGSMASK 0x3fL
FILEFLAGS 0
FILEOS 0x40004L
FILETYPE 1
FILESUBTYPE 0
BEGIN
 BLOCK "StringFileInfo"
 BEGIN
  BLOCK "040904b0"
  BEGIN
   VALUE "CompanyName", "whispr.dev\\0"
   VALUE "FileDescription", "whispr VPN automatic setup\\0"
   VALUE "FileVersion", "1.0.3.0\\0"
   VALUE "ProductName", "whispr VPN\\0"
   VALUE "ProductVersion", "1.0.3\\0"
   VALUE "OriginalFilename", "whispr-vpn-1.0.3-setup.exe\\0"
  END
 END
 BLOCK "VarFileInfo"
 BEGIN
  VALUE "Translation", 0x409, 1200
 END
END
"""
(s/'launcher.rc').write_text(text)
subprocess.run([os.environ.get('MINGW_WINDRES','x86_64-w64-mingw32-windres'),str(s/'launcher.rc'),'-O','coff','-o',str(s/'launcher-res.o')],check=True)
output=r/'dist/whispr-vpn-1.0.3-setup.exe'
subprocess.run([os.environ.get('MINGW_CC','x86_64-w64-mingw32-gcc'),'-std=c11','-O2','-Wall','-Wextra','-Werror','-mwindows','-municode','-static-libgcc','-Wl,--no-insert-timestamp',str(s/'launcher.c'),str(s/'launcher-res.o'),'-o',str(output),'-lshell32','-ladvapi32','-lbcrypt','-lgdi32'],check=True)
print(json.dumps({'setup':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'bytes':output.stat().st_size,'embedded_msi_sha256':digest},indent=2))
