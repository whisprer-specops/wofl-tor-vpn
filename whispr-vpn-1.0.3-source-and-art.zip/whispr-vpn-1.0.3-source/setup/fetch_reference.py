#!/usr/bin/env python3
"""Fetch build-only official .NET Framework 4.8 reference metadata, pinned by SHA-256."""
import hashlib,urllib.request,zipfile
from pathlib import Path
r=Path(__file__).resolve().parents[1]
url='https://api.nuget.org/v3-flatcontainer/microsoft.netframework.referenceassemblies.net48/1.0.3/microsoft.netframework.referenceassemblies.net48.1.0.3.nupkg'
expected='8a7e348538e7eb91351696911689f49e3d4f63f8bab517432bbe159b8b1104a2'
p=r/'downloads/microsoft.netframework.referenceassemblies.net48.1.0.3.nupkg';p.parent.mkdir(exist_ok=True)
if not p.exists():
 with urllib.request.urlopen(url,timeout=60) as response:p.write_bytes(response.read())
assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,'Reference package SHA-256 mismatch'
with zipfile.ZipFile(p) as z:
 names=[n for n in z.namelist() if n.endswith('/mscorlib.dll')];assert len(names)==1
 out=r/'setup/reference/mscorlib.dll';out.parent.mkdir(exist_ok=True);out.write_bytes(z.read(names[0]))
print('VERIFIED: official build-only net48 reference; no compiler/reference package is needed by the installed client.')
