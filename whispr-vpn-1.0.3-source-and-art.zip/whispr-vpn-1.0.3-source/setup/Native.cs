using System;
using System.Text;
using System.Runtime.InteropServices;
public static class WhisprSetupNative103 {
 [DllImport("shell32.dll",CharSet=CharSet.Unicode,ExactSpelling=true,SetLastError=true)] static extern IntPtr CommandLineToArgvW(string command,out int count);
 [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr p);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,uint id);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,ExactSpelling=true,SetLastError=true)] static extern bool QueryFullProcessImageNameW(IntPtr process,uint flags,StringBuilder name,ref int size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr h,out long creation,out long exit,out long kernel,out long user);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(IntPtr h,uint exitCode);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr h,uint milliseconds);
 public static string[] Args(string command) {
   int count;IntPtr p=CommandLineToArgvW(command,out count);if(p==IntPtr.Zero)throw new InvalidOperationException("Cannot parse a process command line.");
   try{var result=new string[count];for(int i=0;i<count;i++)result[i]=Marshal.PtrToStringUni(Marshal.ReadIntPtr(p,i*IntPtr.Size));return result;}finally{LocalFree(p);}
 }
 public static bool Stop(uint pid,string expectedPath,long expectedCreation) {
   IntPtr h=OpenProcess(0x00101001,false,pid);if(h==IntPtr.Zero){if(Marshal.GetLastWin32Error()==87)return false;throw new InvalidOperationException("Cannot open verified whispr process "+pid);}
   try {
     var path=new StringBuilder(32768);int size=path.Capacity;long created,exited,kernel,user;
     if(!QueryFullProcessImageNameW(h,0,path,ref size)||!GetProcessTimes(h,out created,out exited,out kernel,out user))throw new InvalidOperationException("Cannot recheck whispr process identity.");
     // CIM creation timestamps have microsecond precision; the held HANDLE prevents PID recycling after this check.
     if(!String.Equals(path.ToString(),expectedPath,StringComparison.OrdinalIgnoreCase)||Math.Abs(created-expectedCreation)>10)return false;
     if(WaitForSingleObject(h,0)==0)return false;
     if(!TerminateProcess(h,0)){if(WaitForSingleObject(h,0)==0)return false;throw new InvalidOperationException("Cannot stop verified whispr process "+pid);}
     if(WaitForSingleObject(h,10000)!=0)throw new InvalidOperationException("Verified whispr process did not finish stopping.");return true;
   }finally{CloseHandle(h);}
 }
}
