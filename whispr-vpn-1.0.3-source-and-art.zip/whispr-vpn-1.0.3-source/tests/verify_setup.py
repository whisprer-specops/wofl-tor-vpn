#!/usr/bin/env python3
"""Inspect the delivered PE and compare embedded resources, not just build inputs."""
import hashlib,json,struct
from pathlib import Path
r=Path(__file__).resolve().parents[1];p=r/'dist/whispr-vpn-1.0.3-setup.exe';b=p.read_bytes()
def u16(o):return struct.unpack_from('<H',b,o)[0]
def u32(o):return struct.unpack_from('<I',b,o)[0]
assert b[:2]==b'MZ';pe=u32(0x3c);assert b[pe:pe+4]==b'PE\0\0'
assert u16(pe+4)==0x8664,'Setup must be x64'
opt=pe+24;assert u16(opt)==0x20b and u16(opt+68)==2,'Setup must use the GUI subsystem'
count=u16(pe+6);section_table=opt+u16(pe+20)
sections=[]
for i in range(count):
 o=section_table+40*i;sections.append((u32(o+12),max(u32(o+8),u32(o+16)),u32(o+20)))
def file_offset(rva):
 for va,size,raw in sections:
  if va<=rva<va+size:return raw+rva-va
 raise AssertionError('RVA outside mapped sections')
base=file_offset(u32(opt+112+2*8))
def directory(relative):
 o=base+relative;entries={}
 for i in range(u16(o+12)+u16(o+14)):
  name,value=struct.unpack_from('<II',b,o+16+8*i)
  if not name&0x80000000:entries[name]=value
 return entries
def resource(kind,name):
 type_dir=directory(0)[kind];assert type_dir&0x80000000
 name_dir=directory(type_dir&0x7fffffff)[name];assert name_dir&0x80000000
 languages=directory(name_dir&0x7fffffff);assert len(languages)==1
 leaf=next(iter(languages.values()));assert not leaf&0x80000000
 data,size=struct.unpack_from('<II',b,base+leaf);o=file_offset(data)
 return b[o:o+size]
msi=r/'dist/whispr-vpn-1.0.2-x64.msi';script=r/'setup/Setup.ps1';guard=r/'packs/friend/app/bin/whispr-vpn-guard.exe'
for rid,source in [(201,msi),(202,script),(203,guard),(204,r/'setup/bin/Whispr.Setup.Native.dll')]:assert resource(10,rid)==source.read_bytes(),f'Embedded resource differs: {rid}'
assert b'Add-Type' not in resource(10,202)
assert hashlib.sha256(resource(10,204)).hexdigest() in (r/'setup/package_hash.h').read_text()
assert b'requireAdministrator' in resource(24,1)
assert hashlib.sha256(resource(10,203)).hexdigest()=='44863a7faf76f8877681283f6a16e4cb02a3c051117439345c469364a4306ea6'
assert hashlib.sha256(resource(10,201)).hexdigest() in (r/'setup/package_hash.h').read_text()
assert 101 in directory(directory(0)[14]&0x7fffffff),'Branded icon group missing'
report={'result':'PASS','setup_sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'msi_sha256':hashlib.sha256(msi.read_bytes()).hexdigest(),'architecture':'x64 GUI','uac_manifest':'requireAdministrator','embedded_resources_exact':True,'native_windows_execution_tested':False,'checks':['PE headers and mapped resource tree','entire embedded MSI/script/original guard compared byte-for-byte','pinned MSI/guard hash checks','GUI subsystem, x64 and elevation manifest','branded icon group']}
(r/'dist/SETUP-VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
