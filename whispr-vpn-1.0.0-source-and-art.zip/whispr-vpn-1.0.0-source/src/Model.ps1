#requires -Version 7.2
Set-StrictMode -Version 3
$script:SuiteProduct='whispr-vpn-desktop-1'
function Get-SuiteCoreRoot {Join-Path $env:ProgramFiles 'whispr Hybrid VPN'}
function Get-SuiteStateRoot {Join-Path $env:ProgramData 'whispr-hybrid'}
function Get-SuiteWorkRoot {Join-Path $env:ProgramData 'whispr-vpn-desktop'}
function Read-SuiteJson([string]$Path){
    try{
        $file=Get-Item -LiteralPath $Path -Force
        if($file -isnot [IO.FileInfo] -or $file.Length -gt 8388608 -or $file.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Unexpected JSON file.'}
        return (Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json -AsHashtable)
    }catch{throw "Cannot read the expected JSON document: $([IO.Path]::GetFileName($Path)). Contents withheld."}
}
function Write-SuiteJson($Value,[string]$Path){
    $temporary=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try{[IO.File]::WriteAllText($temporary,($Value|ConvertTo-Json -Depth 50),[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $temporary -Destination $Path -Force}
    finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force}}
}
function Assert-SuiteDirectory([string]$Path){
    $item=Get-Item -LiteralPath $Path -Force
    if($item -isnot [IO.DirectoryInfo] -or $item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Unexpected directory or link: '+$Path}
    if((Get-Acl -LiteralPath $Path).GetOwner([Security.Principal.SecurityIdentifier]).Value -notin @('S-1-5-18','S-1-5-32-544')){throw 'Unrecognised directory owner: '+$Path}
}
function Initialize-SuiteWorkspace {
    $root=Get-SuiteWorkRoot
    if(-not (Test-Path -LiteralPath $root)){
        [void](New-Item -ItemType Directory -Path $root)
        & icacls.exe $root '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '/setowner' '*S-1-5-32-544' | Out-Null
        if($LASTEXITCODE -ne 0){throw 'Could not secure the local workspace.'}
    }
    Assert-SuiteDirectory $root
    foreach($name in @('group','exports','jobs')){
        $path=Join-Path $root $name
        if(-not (Test-Path -LiteralPath $path)){[void](New-Item -ItemType Directory -Path $path)}
        $item=Get-Item -LiteralPath $path -Force
        if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Unexpected workspace link.'}
    }
    return $root
}
function Assert-SuiteManifest([string]$SuiteRoot){
    $manifest=Read-SuiteJson (Join-Path $SuiteRoot 'suite-manifest.json')
    foreach($relative in $manifest.Keys){
        if($relative -match '(^[/\\]|(^|[/\\])\.\.([/\\]|$)|:)'){throw 'Invalid suite manifest path.'}
        $path=Join-Path $SuiteRoot $relative
        $item=Get-Item -LiteralPath $path -Force
        if($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -cne $manifest[$relative]){throw 'Installed suite integrity check failed: '+$relative}
    }
}
function Get-SuiteHostChoice([string[]]$TaskHosts,[string]$GlobalHost,[string]$BundledHost){
    $hosts=@($TaskHosts|Where-Object {$_}|Sort-Object -Unique)
    if($hosts.Count -gt 1){throw 'Existing VPN tasks use different PowerShell hosts. They were not changed. Open the original tray shortcut.'}
    if($hosts.Count -eq 1){
        if($hosts[0] -ine $GlobalHost -and $hosts[0] -ine $BundledHost){throw 'The existing VPN uses a custom PowerShell host. Use its original shortcut; automatic host migration was refused.'}
        return $hosts[0]
    }
    if(Test-Path -LiteralPath $GlobalHost){return $GlobalHost}
    return $BundledHost
}
function Update-SuiteRuntimeLease([string]$SuiteRoot){
    $needed=$false;$core=Get-SuiteCoreRoot
    $marker=Join-Path $core 'desktop-owned.json'
    if(Test-Path -LiteralPath $marker){
        $record=Read-SuiteJson $marker
        if($record.Product -eq $script:SuiteProduct -and $record.SuiteRoot -ieq $SuiteRoot){$needed=$true}
    }
    $service=New-Object -ComObject Schedule.Service
    try{
        $service.Connect()
        foreach($task in $service.GetFolder('\').GetTasks(1)){
            foreach($a in $task.Definition.Actions){
                if($a.Type -eq 0 -and [string]$a.Path -ieq (Join-Path $SuiteRoot 'runtime/powershell/pwsh.exe')){$needed=$true}
            }
        }
    }finally{if([Runtime.InteropServices.Marshal]::IsComObject($service)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($service)}}
    $path='HKLM:\Software\whispr.dev\VPN Desktop'
    [void](New-Item -Path $path -Force)
    [void](New-ItemProperty -LiteralPath $path -Name CoreRuntimeLease -PropertyType String -Value $(if($needed){'1'}else{'0'}) -Force)
    return $needed
}
function Get-SuiteCoreHost([string]$SuiteRoot){
    $globalHost=Join-Path $env:ProgramFiles 'PowerShell\7\pwsh.exe'
    $bundled=Join-Path $SuiteRoot 'runtime\powershell\pwsh.exe'
    $core=Get-SuiteCoreRoot;$hosts=[Collections.Generic.List[string]]::new()
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    try{$sid=$identity.User.Value}finally{$identity.Dispose()}
    $service=New-Object -ComObject Schedule.Service
    try{
        $service.Connect();$folder=$service.GetFolder('\')
        foreach($kind in @('Background','Autostart')){
            $name='whispr-HybridVPN-'+$kind+'-'+$sid
            $task=$null
            try{$task=$folder.GetTask($name)}catch{
                $code=[uint32]([long]$_.Exception.GetBaseException().HResult -band 0xffffffffL)
                if($code -ne 0x80070002L){throw}
            }
            if($task){
                $d=$task.Definition
                $source=if($kind -eq 'Background'){'whispr-hybrid-on-demand-v1'}else{'whispr-hybrid-autostart-v1'}
                $working=if($kind -eq 'Background'){Join-Path $core 'background'}else{$core}
                $scriptPath=if($kind -eq 'Background'){Join-Path $core 'background\Scheduled-Host.ps1'}else{Join-Path $core 'Tray.ps1'}
                if($d.RegistrationInfo.Source -ne $source -or $d.Actions.Count -ne 1){throw 'Existing VPN task ownership differs.'}
                $a=$d.Actions.Item(1)
                if($a.Type -ne 0 -or $a.WorkingDirectory -ine $working -or -not $a.Arguments.Contains($scriptPath)){throw 'Existing VPN task action differs.'}
                $hosts.Add([string]$a.Path)
            }
        }
    }finally{if([Runtime.InteropServices.Marshal]::IsComObject($service)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($service)}}
    $hostPath=Get-SuiteHostChoice @($hosts.ToArray()) $globalHost $bundled
    if(-not (Test-Path -LiteralPath $hostPath -PathType Leaf)){throw 'The PowerShell host recorded by the existing VPN is missing. No task was changed.'}
    return $hostPath
}
function Assert-SuiteCore {
    $core=Get-SuiteCoreRoot;$state=Get-SuiteStateRoot
    foreach($root in @($core,$state)){
        Assert-SuiteDirectory $root
        if((Get-Content -LiteralPath (Join-Path $root 'install-owner.txt') -Raw).Trim() -ne 'whispr-hybrid-schema-1'){throw 'Existing VPN ownership marker differs.'}
    }
    . "$core/client/Common.ps1";Assert-HybridManifest $core
    return $core
}
function Sync-SuiteGroupTools([string]$SuiteRoot){
    $workspace=Initialize-SuiteWorkspace;$dest=Join-Path $workspace 'group';$source=Join-Path $SuiteRoot 'packs/group'
    $manifest=Read-SuiteJson (Join-Path $source 'PACKAGE-SHA256SUMS.json')
    foreach($relative in @($manifest.Keys)+@('PACKAGE-SHA256SUMS.json')){
        if($relative -match '(^[/\\]|(^|[/\\])\.\.([/\\]|$)|:)'){throw 'Invalid group package path.'}
        $from=Join-Path $source $relative;$to=Join-Path $dest $relative
        $parent=Split-Path $to -Parent
        [void](New-Item -ItemType Directory -Path $parent -Force)
        if(@(Get-Item -LiteralPath $parent -Force|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count){throw 'Unexpected group workspace directory link.'}
        if((Test-Path -LiteralPath $to) -and ((Get-Item -LiteralPath $to -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Unexpected group workspace file link.'}
        if(-not (Test-Path -LiteralPath $to) -or (Get-FileHash -LiteralPath $from).Hash -ne (Get-FileHash -LiteralPath $to).Hash){Copy-Item -LiteralPath $from -Destination $to -Force}
    }
    $config=Join-Path $dest 'my-vps.json'
    if(-not (Test-Path -LiteralPath $config)){Copy-Item -LiteralPath (Join-Path $source 'my-vps.json') -Destination $config}
    $catalog=Join-Path (Get-SuiteStateRoot) 'group-catalog.json'
    if(-not (Test-Path -LiteralPath (Join-Path $dest 'group.json')) -and (Test-Path -LiteralPath $catalog)){
        $c=Read-SuiteJson $catalog
        . "$dest/group/Protocol.ps1";Assert-GroupDocument $c.Group
        Write-SuiteJson $c.Group (Join-Path $dest 'group.json')
    }
    return $dest
}
function New-SuitePublicRequest([string]$DeviceName,[string]$OutputDirectory){
    $core=Assert-SuiteCore;$state=Get-SuiteStateRoot
    if($DeviceName -cnotmatch '^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$'){throw 'Use a short device name containing letters, numbers, spaces, dot, underscore or hyphen.'}
    $key=Read-SuiteJson (Join-Path $state 'device-key.json')
    $public=[string]$key.PublicKey
    $fingerprint=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Convert]::FromBase64String($public))).ToLowerInvariant()
    $stored=Join-Path $state 'friend-request.json'
    if(Test-Path -LiteralPath $stored){
        $request=Read-SuiteJson $stored
        if($request.PublicKey -cne $public -or $request.Fingerprint -cne $fingerprint){throw 'Stored public request does not match this device.'}
    }else{
        $request=@{Schema=1;Kind='whispr-friend-request';RequestId=[guid]::NewGuid().ToString('N');PublicKey=$public;Fingerprint=$fingerprint;DeviceName=$DeviceName;CreatedUtc=[DateTime]::UtcNow.ToString('o')}
        Write-SuiteJson $request $stored
    }
    $key=$null
    . "$PSScriptRoot/packs/friend/app/friend/Protocol.ps1"
    Assert-FriendRequest $request
    Write-SuiteJson $request (Join-Path $OutputDirectory 'friend-request.json')
}
