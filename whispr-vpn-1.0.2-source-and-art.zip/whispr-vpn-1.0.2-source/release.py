#!/usr/bin/env python3
"""Package the verified one-file setup, MSI, complete sources and instructions."""
from pathlib import Path
import hashlib,json,shutil,zipfile
r=Path(__file__).resolve().parent;d=r/'dist/release';d.mkdir(exist_ok=True)
verification=json.loads((r/'dist/VERIFICATION.json').read_text());setup_report=json.loads((r/'dist/SETUP-VERIFICATION.json').read_text())
assert verification['result']==setup_report['result']=='PASS'
for name,wanted in [('whispr-vpn-1.0.2-x64.msi',verification['msi_sha256']),('whispr-vpn-1.0.2-setup.exe',setup_report['setup_sha256'])]:
 source=r/'dist'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==wanted;shutil.copy2(source,d/name)
kit=d/'whispr-vpn-1.0.2-source-and-art.zip';prefix='whispr-vpn-1.0.2-source/'
with zipfile.ZipFile(kit,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in ['README.md','BUILD.md','THIRD-PARTY.md','LICENSE.md','dependencies.lock.json','fetch_dependencies.py','prepare.py','build_msi.py','release.py']:z.write(r/name,prefix+name)
 for folder in ['src','art','packs','tests','native','setup']:
  for p in sorted((r/folder).rglob('*')):
   if not p.is_file() or '__pycache__' in p.parts or p.name=='policy_test' or p.suffix in {'.o','.pyc','.rc'} or any(part.startswith('.') for part in p.relative_to(r).parts):continue
   z.write(p,prefix+p.relative_to(r).as_posix())
 for name in ['VERIFICATION.json','SETUP-VERIFICATION.json','build-metadata.json','SOURCE-VALIDATION.txt']:z.write(r/'dist'/name,prefix+'validation/'+name)
 for name in ['LICENSE.txt','ThirdPartyNotices.txt']:z.write(r/'payload/runtime/powershell'/name,prefix+'runtime-notices/powershell/'+name)
with zipfile.ZipFile(kit) as z:assert z.testzip() is None
shutil.copy2(r/'README.md',d/'WHISPR-SETUP-READ-ME.md')
(d/'WHISPR-SETUP-SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in sorted(d.iterdir()) if p.is_file() and p.name!='WHISPR-SETUP-SHA256SUMS.txt')+'\n')
for p in sorted(d.iterdir()):print(f'{p.name}: {p.stat().st_size:,} bytes')
