#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <aclapi.h>
#include <sddl.h>
#include <bcrypt.h>
#include <strsafe.h>
#include <commctrl.h>
#include <stdio.h>
#include "package_hash.h"
#define CAP 4096
#define VERSION L"1.0.2"
static HWND window, label, close_button;
static wchar_t package[CAP], journal[CAP], detail[CAP];
static DWORD result_code=1;
static volatile LONG finished=0;
static HANDLE resource_locks[3]={INVALID_HANDLE_VALUE,INVALID_HANDLE_VALUE,INVALID_HANDLE_VALUE};
static void join(wchar_t *out,const wchar_t *root,const wchar_t *leaf){StringCchCopyW(out,CAP,root);StringCchCatW(out,CAP,L"\\");StringCchCatW(out,CAP,leaf);}
static int fail(const wchar_t *message){StringCchCopyW(detail,CAP,message);return 0;}
static int protected_directory(const wchar_t *p){
 PSECURITY_DESCRIPTOR sd=NULL;SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,FALSE};
 if(!ConvertStringSecurityDescriptorToSecurityDescriptorW(L"O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)",SDDL_REVISION_1,&sd,NULL))return fail(L"Cannot prepare the protected setup directory.");
 sa.lpSecurityDescriptor=sd;BOOL made=CreateDirectoryW(p,&sa);DWORD e=GetLastError();LocalFree(sd);
 if(!made&&e!=ERROR_ALREADY_EXISTS)return fail(L"Cannot create the protected setup directory.");
 DWORD attrs=GetFileAttributesW(p);if(attrs==INVALID_FILE_ATTRIBUTES||!(attrs&FILE_ATTRIBUTE_DIRECTORY)||(attrs&FILE_ATTRIBUTE_REPARSE_POINT))return fail(L"The setup directory is not a normal directory. No process was stopped.");
 PSID owner=NULL;PACL acl=NULL;sd=NULL;
 if(GetNamedSecurityInfoW((wchar_t*)p,SE_FILE_OBJECT,OWNER_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION,&owner,NULL,&acl,NULL,&sd)!=ERROR_SUCCESS)return fail(L"Cannot check the protected setup directory.");
 int okay=owner&&(IsWellKnownSid(owner,WinLocalSystemSid)||IsWellKnownSid(owner,WinBuiltinAdministratorsSid))&&acl&&IsValidAcl(acl)&&acl->AceCount>0;
 for(DWORD i=0;okay&&i<acl->AceCount;i++){void *raw=NULL;if(!GetAce(acl,i,&raw)){okay=0;break;}ACE_HEADER *head=(ACE_HEADER*)raw;if(head->AceType!=ACCESS_ALLOWED_ACE_TYPE){okay=0;break;}ACCESS_ALLOWED_ACE *ace=(ACCESS_ALLOWED_ACE*)raw;PSID sid=(PSID)&ace->SidStart;if(!IsWellKnownSid(sid,WinLocalSystemSid)&&!IsWellKnownSid(sid,WinBuiltinAdministratorsSid))okay=0;}
 LocalFree(sd);return okay?1:fail(L"The setup directory does not have the expected administrator/SYSTEM-only permissions. No process was stopped.");
}
static int sha_bytes(const BYTE *data,DWORD size,BYTE digest[32]){
 BCRYPT_ALG_HANDLE a=NULL;BCRYPT_HASH_HANDLE h=NULL;int okay=0;
 if(BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
 if(BCryptCreateHash(a,&h,NULL,0,NULL,0,0)<0)goto done;
 if(BCryptHashData(h,(BYTE*)data,size,0)<0)goto done;
 okay=BCryptFinishHash(h,digest,32,0)>=0;
 done:if(h)BCryptDestroyHash(h);if(a)BCryptCloseAlgorithmProvider(a,0);return okay;
}
static int same_file(const wchar_t *p,const BYTE *resource,DWORD size){
 DWORD attrs=GetFileAttributesW(p);if(attrs==INVALID_FILE_ATTRIBUTES||(attrs&(FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY)))return 0;
 HANDLE f=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);if(f==INVALID_HANDLE_VALUE)return 0;
 LARGE_INTEGER length;int same=0;BYTE expected[32],actual[32],buffer[65536];BCRYPT_ALG_HANDLE a=NULL;BCRYPT_HASH_HANDLE h=NULL;
 if(!GetFileSizeEx(f,&length)||length.QuadPart!=size||!sha_bytes(resource,size,expected))goto done;
 if(BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,NULL,0)<0||BCryptCreateHash(a,&h,NULL,0,NULL,0,0)<0)goto done;
 for(;;){DWORD got=0;if(!ReadFile(f,buffer,sizeof(buffer),&got,NULL))goto done;if(!got)break;if(BCryptHashData(h,buffer,got,0)<0)goto done;}
 if(BCryptFinishHash(h,actual,32,0)>=0)same=!memcmp(expected,actual,32);
 done:if(h)BCryptDestroyHash(h);if(a)BCryptCloseAlgorithmProvider(a,0);CloseHandle(f);return same;
}
static int extract(int id,const wchar_t *name,const wchar_t *nonce){
 HRSRC r=FindResourceW(NULL,MAKEINTRESOURCEW(id),RT_RCDATA);if(!r)return fail(L"An embedded installer resource is missing.");
 HGLOBAL loaded=LoadResource(NULL,r);DWORD size=SizeofResource(NULL,r);const BYTE *bytes=(const BYTE*)LockResource(loaded);if(!bytes||!size)return fail(L"An embedded installer resource cannot be read.");
 wchar_t output[CAP];join(output,package,name);DWORD attrs=GetFileAttributesW(output);
 if(attrs!=INVALID_FILE_ATTRIBUTES){
  if(attrs&(FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY))return fail(L"An expected setup file is a directory or link. Nothing was followed.");
  if(same_file(output,bytes,size))return 1;
  wchar_t backup[CAP];StringCchPrintfW(backup,CAP,L"%s.previous-%s",output,nonce);
  if(!MoveFileW(output,backup))return fail(L"A damaged cached setup file could not be preserved before replacement.");
 }
 HANDLE f=CreateFileW(output,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return fail(L"Cannot write the protected installer resource.");
 DWORD offset=0;int okay=1;while(offset<size){DWORD n=size-offset;if(n>1048576)n=1048576;DWORD written=0;if(!WriteFile(f,bytes+offset,n,&written,NULL)||written!=n){okay=0;break;}offset+=written;}
 if(!FlushFileBuffers(f))okay=0;
 CloseHandle(f);
 return okay&&same_file(output,bytes,size)?1:fail(L"The extracted setup resource failed its byte-integrity check.");
}
static int lock_resources(void){
 const wchar_t *names[]={L"whispr-vpn-1.0.2-x64.msi",L"Setup.ps1",L"whispr-vpn-guard.exe"};
 for(int i=0;i<3;i++){
  wchar_t p[CAP];join(p,package,names[i]);resource_locks[i]=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);
  if(resource_locks[i]==INVALID_HANDLE_VALUE)return fail(L"Cannot lock verified setup files against modification during installation.");
  HRSRC resource=FindResourceW(NULL,MAKEINTRESOURCEW(201+i),RT_RCDATA);
  if(!resource||!same_file(p,(const BYTE*)LockResource(LoadResource(NULL,resource)),SizeofResource(NULL,resource)))return fail(L"A protected setup resource changed before it could be locked.");
 }
 return 1;
}
static void read_text(const wchar_t *name,wchar_t *text,DWORD count){
 wchar_t p[CAP];join(p,journal,name);HANDLE f=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);if(f==INVALID_HANDLE_VALUE)return;
 DWORD got=0;if(ReadFile(f,text,(count-1)*sizeof(wchar_t),&got,NULL))text[got/sizeof(wchar_t)]=0;CloseHandle(f);
}
static DWORD WINAPI work(void *unused){
 (void)unused;wchar_t common[MAX_PATH],root[CAP],packages[CAP],logs[CAP],nonce[33];BYTE random[16];
 if(BCryptGenRandom(NULL,random,sizeof(random),BCRYPT_USE_SYSTEM_PREFERRED_RNG)<0){fail(L"Cannot create a setup transaction identifier.");goto done;}
 for(int i=0;i<16;i++)StringCchPrintfW(nonce+i*2,3,L"%02x",random[i]);
 nonce[32]=0;
 if(FAILED(SHGetFolderPathW(NULL,CSIDL_COMMON_APPDATA,NULL,SHGFP_TYPE_CURRENT,common))){fail(L"Cannot find the shared application-data directory.");goto done;}
 join(root,common,L"whispr-vpn-setup");if(!protected_directory(root))goto done;
 join(packages,root,L"packages");if(!protected_directory(packages))goto done;
 join(package,packages,VERSION);if(!protected_directory(package))goto done;
 join(logs,root,L"transactions");if(!protected_directory(logs))goto done;
 join(journal,logs,nonce);if(!protected_directory(journal))goto done;
 if(!extract(201,L"whispr-vpn-1.0.2-x64.msi",nonce)||!extract(202,L"Setup.ps1",nonce)||!extract(203,L"whispr-vpn-guard.exe",nonce))goto done;
 if(!lock_resources())goto done;
 wchar_t sys[MAX_PATH],host[CAP],script[CAP],command[CAP*3],output[CAP];
 if(!GetSystemDirectoryW(sys,MAX_PATH)){fail(L"Cannot resolve Windows PowerShell.");goto done;}
 join(host,sys,L"WindowsPowerShell\\v1.0\\powershell.exe");join(script,package,L"Setup.ps1");join(output,journal,L"powershell.log");
 StringCchPrintfW(command,CAP*3,L"\"%s\" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"%s\" -PackageRoot \"%s\" -JournalRoot \"%s\" -ExpectedMsiHash %s",host,script,package,journal,MSI_SHA256);
 SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};HANDLE log=CreateFileW(output,GENERIC_WRITE,FILE_SHARE_READ,&sa,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);HANDLE nul=CreateFileW(L"NUL",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,NULL);
 if(log==INVALID_HANDLE_VALUE||nul==INVALID_HANDLE_VALUE){if(log!=INVALID_HANDLE_VALUE)CloseHandle(log);if(nul!=INVALID_HANDLE_VALUE)CloseHandle(nul);fail(L"Cannot open the setup log.");goto done;}
 STARTUPINFOW si={0};si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdInput=nul;si.hStdOutput=log;si.hStdError=log;PROCESS_INFORMATION pi={0};
 BOOL started=CreateProcessW(host,command,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,package,&si,&pi);CloseHandle(log);CloseHandle(nul);
 if(!started){fail(L"Windows PowerShell could not start. No app process was stopped.");goto done;}
 CloseHandle(pi.hThread);WaitForSingleObject(pi.hProcess,INFINITE);GetExitCodeProcess(pi.hProcess,&result_code);CloseHandle(pi.hProcess);
 if(result_code!=0&&result_code!=3010){read_text(L"error.txt",detail,CAP);if(!detail[0])fail(L"The setup helper stopped. Its PowerShell and MSI logs are in the setup journal.");}
 done:for(int i=0;i<3;i++){if(resource_locks[i]!=INVALID_HANDLE_VALUE){CloseHandle(resource_locks[i]);resource_locks[i]=INVALID_HANDLE_VALUE;}}
 InterlockedExchange(&finished,1);PostMessageW(window,WM_APP,0,0);return 0;
}
static LRESULT CALLBACK procedure(HWND h,UINT msg,WPARAM w,LPARAM l){
 if(msg==WM_CLOSE){if(InterlockedCompareExchange(&finished,0,0))DestroyWindow(h);return 0;}
 if(msg==WM_COMMAND&&LOWORD(w)==1){if(InterlockedCompareExchange(&finished,0,0))DestroyWindow(h);return 0;}
 if(msg==WM_TIMER){wchar_t status[2048]={0};if(journal[0])read_text(L"status.txt",status,2048);if(status[0])SetWindowTextW(label,status);return 0;}
 if(msg==WM_APP){
  KillTimer(h,1);EnableWindow(close_button,TRUE);
  if(result_code==0||result_code==3010){SetWindowTextW(label,result_code==3010?L"Installation finished. Windows requests a restart. Your keys, exits and startup preference were retained.":L"Installation finished. Your keys, exits and startup preference were retained. Open whispr VPN from Start to reconnect.");}
  else{wchar_t error[CAP*2];StringCchPrintfW(error,CAP*2,L"%s\n\nSetup journal:\n%s\n\nDo not stop random Windows processes. Setup logs identify the precise failure.",detail[0]?detail:L"Setup stopped.",journal);SetWindowTextW(label,L"Setup stopped. The displayed journal contains the exact failure and recovery record.");MessageBoxW(h,error,L"whispr VPN setup",MB_OK);}
  return 0;
 }
 if(msg==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(h,msg,w,l);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,LPWSTR command,int show){
 (void)previous;(void)command;(void)show;HANDLE mutex=CreateMutexW(NULL,TRUE,L"Global\\whisprVpnSetupLauncher");if(!mutex)return 1;if(GetLastError()==ERROR_ALREADY_EXISTS){MessageBoxW(NULL,L"whispr setup is already running. Its window or Windows Installer may be behind another window.",L"whispr VPN setup",MB_OK);CloseHandle(mutex);return 1;}
 int consent=MessageBoxW(NULL,L"Setup will disconnect whispr VPN and stop its verified tasks/processes before opening Windows Installer. Your keys, exit profiles and whispr startup preference are retained.\n\nNormal Internet access will be restored during setup. Continue?",L"whispr VPN 1.0.2 setup",MB_OKCANCEL|MB_DEFBUTTON1);
 if(consent!=IDOK){ReleaseMutex(mutex);CloseHandle(mutex);return 1602;}
 WNDCLASSW wc={0};wc.lpfnWndProc=procedure;wc.hInstance=instance;wc.lpszClassName=L"WhisprVpnSetup102";wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(101));if(!RegisterClassW(&wc)){ReleaseMutex(mutex);CloseHandle(mutex);return 1;}
 window=CreateWindowExW(0,wc.lpszClassName,L"whispr VPN setup",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,580,230,NULL,NULL,instance,NULL);if(!window){ReleaseMutex(mutex);CloseHandle(mutex);return 1;}
 label=CreateWindowW(L"STATIC",L"Preparing the verified installer and automatic whispr cleanup...",WS_CHILD|WS_VISIBLE,24,30,520,90,window,NULL,instance,NULL);
 close_button=CreateWindowW(L"BUTTON",L"Close",WS_CHILD|WS_VISIBLE|WS_DISABLED|BS_DEFPUSHBUTTON,440,140,100,30,window,(HMENU)1,instance,NULL);
 HFONT font=(HFONT)GetStockObject(DEFAULT_GUI_FONT);SendMessageW(label,WM_SETFONT,(WPARAM)font,TRUE);SendMessageW(close_button,WM_SETFONT,(WPARAM)font,TRUE);ShowWindow(window,SW_SHOW);UpdateWindow(window);SetTimer(window,1,750,NULL);
 HANDLE worker=CreateThread(NULL,0,work,NULL,0,NULL);if(!worker){fail(L"Cannot start setup.");InterlockedExchange(&finished,1);PostMessageW(window,WM_APP,0,0);}else CloseHandle(worker);
 MSG msg;while(GetMessageW(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}ReleaseMutex(mutex);CloseHandle(mutex);return (int)result_code;
}
