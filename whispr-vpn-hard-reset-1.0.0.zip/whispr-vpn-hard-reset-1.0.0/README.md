# whispr VPN hard reset — wofl's recovery kit 1.0.0

This is the exceptional recovery tool for the accumulated whispr Hybrid VPN / old
TorVPN installations. It is separate from the normal MSI. It uses Windows' built-in
64-bit Windows PowerShell 5.1, so a broken or half-removed PowerShell 7 runtime does
not prevent it from starting. No downloads or compilation are needed on the PC.

## Run

1. Extract the ZIP completely into its own folder. Close the failed MSI/setup window.
2. Double-click **RUN-HARD-RESET.cmd** and approve the Windows administrator prompt.
   The whispr VPN connection will drop. Let the window finish.
3. If it requests a restart, restart Windows once. A protected one-shot SYSTEM task
   retries locked leftovers at startup, then removes its task. Its own temporary
   working files are removed after that attempt. Run **AUDIT-ONLY.cmd** afterward.
4. To keep using your old exit registrations, double-click
   **RESTORE-DEVICE-IDENTITY.cmd immediately after successful cleanup and before
   installing the MSI**. It restores only the protected key/profile backup, not the
   old program, processes, tasks, firewall, runtime or MSI registration.
5. Install your existing `whispr-hybrid-vpn-1.1.0-x64.msi`, then open whispr Hybrid VPN.

The reset deletes the installed program and active local configuration. It first
saves device keys, selected peer and exit profiles in a separate protected recovery
folder, including copies found inside quarantined MSI state backups. Backup failure
stops destructive file/registration cleanup. Your original identity is not silently
replaced. Multiple different quarantined identities without a live selection are
all retained; automatic restoration refuses to guess. State already restored or
created by another install is never overwritten by the restore command.

`AUDIT-ONLY.cmd` creates an inventory without changing VPN installations or network
state. Its successful exit means inventory finished; any **FOUND** entry still
exists. Audit does not assert that the computer is clean or that a VPN connects.

## What the reset handles

- Standard 64/32-bit Program Files installations named `whispr Hybrid VPN`,
  `whispr VPN` and `TorVPN`; partial files and broken app-folder permissions.
- ProgramData `whispr-hybrid`, `whispr-vpn-desktop`, `whispr-hybrid-msi`,
  `whispr-vpn-setup` and `torvpn`, including obsolete runtimes and transaction data.
- Resident program processes and PowerShell `-File` hosts positively tied to those
  app folders; failed setup script hosts in the old protected setup workspace.
  Process image and creation time are checked against an opened process handle.
- Verified whispr/TorVPN scheduled tasks, startup values and shortcuts, including
  common Start Menu and enumerated user-profile shortcut locations.
- Verified old TorVPN/whispr services. They are disabled, asked to stop and deleted;
  exact process cleanup follows without waiting indefinitely on Stop-Service.
- The original Rust guard's **own fixed WFP provider**, using the bundled, pinned
  guard executable. It verifies DISARMED afterward; it never resets all WFP policy.
- Exact whispr-hybrid/torvpn adapter instances and their interface routes, recognizable
  phantom PnP devices, recorded legacy relay bypass routes, owned firewall rules and
  the old TorVPN NRPT DNS rule. Shared Wintun/WireGuard driver packages stay installed.
- The legacy TorVPN firewall journal: original profile defaults and recorded Local/
  Dynamic allow rules. Restoration is batched and verified; rules originally disabled
  remain disabled, and expired Dynamic rules are not recreated. Its saved WFP audit
  policy is restored if present. Unrecoverable journals remain for diagnosis.
- Normal quiet MSI removal where possible, followed by product-specific orphan
  registration cleanup even if the cached MSI is missing or its actions fail.
  Known 1.0.0, 1.0.1, 1.0.2 and 1.1.0 product GUIDs and products registered under
  this project's exact UpgradeCode are covered. It removes their Product/Feature/
  UpgradeCode/UserData records and only their client values in shared component keys.
  Other products' component references are preserved. Registry keys are exported
  before deletion. No `Win32_Product` query or whole Installer-cache deletion is used.

## Reports and exit codes

Reports and protected backups are under:

```text
C:\Users\Public\Documents\whispr-VPN-Recovery\<timestamp-id>\
```

The actual Common Documents location is resolved through Windows if it differs.
Windows may request administrator approval when you open the protected folder.
`reset.log` records each stage, `result.json` gives the result and remaining folders,
and `identity` / `alternate-identities` hold the protected device backups. Keys are
not printed in logs. Registry exports and any attempted MSI's verbose log are there
too. Keep this folder until the new installation connects successfully.

- **0**: requested operation completed. For a reset, known checked objects were removed.
- **2**: attention required or restart/retry needed. Do not treat it as a clean result.
- **1**: operation stopped, such as backup failure or Windows Installer already busy.

The reboot task waits 20 seconds after startup and retries once, not forever. If it
finds a client launcher created after the retry was scheduled, it cancels the reset
to protect that newer installation and records the skipped attempt. Identity restore
refuses to run while a retry is pending. A failed boot retry leaves its report and
recovery data. No automatic reboot, automatic VPN connection or server provisioning
is performed. A running Windows Installer transaction is not force-killed; the tool
uses its execute mutex before orphan registration changes.

## Scope and important limits

This is aggressive, targeted recovery, not a promise to recognize every possible
unknown installation. Windows/registry corruption, an unfamiliar custom installation
path, an unloaded user's registry hive, policy-controlled settings or an unrecognized
adapter can require another pass informed by the report. It does not erase Downloads
or source repositories, remove Wireshark/Npcap used by another project, alter your
Ollama or Empyrion configuration, remove other WireGuard tunnels, or reset the whole
firewall, Winsock, TCP/IP, physical NIC DNS or security policy. It does not remove
Windows' own installer cache/logs or remote server public-key registrations.
If a legacy firewall backup is missing, it cannot infer the old profile defaults;
it does not pretend that setting every profile to Allow is a safe reconstruction.

The reset intentionally retains this downloaded kit and its protected reports/identity
backup. Those are recovery artifacts, not resident VPN programs or startup services.
After a verified reinstall, you may delete them yourself if no longer needed.

## Installed Apps entry

The recovered 1.1.0 MSI source is a per-machine Windows Installer product named
**whispr Hybrid VPN** with standard product registration, repair/uninstall UI and no
ARPSYSTEMCOMPONENT hiding flag. It is intended to appear in Settings > Apps > Installed
apps after a successful committed install. A failed/rolled-back installation may have
no entry; an old corrupt registration may be present even when files are missing.
This recovery kit is not installed as a permanent app. No new MSI was required for
the listing request, and no fake Installed Apps entry is added to mask a failed install.

## Validation

`Test-Recovery.ps1` executes 43 contract assertions using real temporary filesystem
copy/delete operations and mocked Windows boundaries. Coverage includes GUID packing,
argument parsing/quoting, process/task ownership, protected process rejection, shared
MSI component client preservation, key/profile byte preservation, quarantined identities,
link traversal refusal, typed firewall restoration and verification, independent stage
failure handling, backup-failure refusal and reboot retry selection.

The script parses and these tests pass under PowerShell 7.6.9 on Linux. Native Windows
PowerShell 5.1 ACL/CIM/SCM/MSI/WFP/PnP execution cannot be certified in this environment.
This is a tested recovery candidate, not a native-Windows acceptance claim.

For developers, run `pwsh -NoProfile -File Test-Recovery.ps1` with PowerShell 7. The
user-facing launchers always select inbox Windows PowerShell, not that test host.

## Tool provenance

`tools/whispr-vpn-guard.exe` is the unchanged recovered fix5 x64 Rust guard:

```text
44863a7faf76f8877681283f6a16e4cb02a3c051117439345c469364a4306ea6
```

Its Rust Cargo source/lockfile and dependency notices are included. There is no new
capture dependency, compiled C# helper or custom DLL in this recovery kit.
The script source is complete and inspectable. SHA256SUMS.txt covers the kit files.

Microsoft references used for implementation:

- https://learn.microsoft.com/en-us/windows/win32/msi/uninstall-registry-key
- https://learn.microsoft.com/en-us/windows/win32/msi/windows-installer-components
- https://learn.microsoft.com/en-us/windows-hardware/drivers/devtest/pnputil-command-syntax
- https://learn.microsoft.com/en-us/powershell/module/netsecurity/get-netfirewallrule
- https://learn.microsoft.com/en-us/powershell/module/nettcpip/remove-netroute
