#requires -Version 7.0
$ErrorActionPreference='Stop'
$scriptPath=Join-Path $PSScriptRoot 'Reset-WhisprVPN.ps1'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($scriptPath,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors.Message -join '; ')}
$forbidden=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -in @('Add-Type','Invoke-Expression','iex')},$true))
if($forbidden.Count){throw 'Recovery must not compile/load custom interop code or evaluate shell strings.'}
. $scriptPath -FunctionsOnly
$script:TestCount=0
function Check($Value,[string]$Message){if(-not $Value){throw $Message};$script:TestCount++}
function Record([string]$Kind,[string]$Text){$script:Events.Add([pscustomobject]@{Kind=$Kind;Message=$Text})}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('whispr-hard-reset-tests-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($temp)
try{
    $script:Data=Join-Path $temp 'data';$script:Report=Join-Path $temp 'report';$script:AppRoots=@((Join-Path $temp 'Program Files/whispr Hybrid VPN'),(Join-Path $temp 'Program Files/whispr VPN'),(Join-Path $temp 'Program Files/TorVPN'))
    $script:Roots=$script:AppRoots;$script:StateRoots=@((Join-Path $script:Data 'whispr-hybrid'),(Join-Path $script:Data 'whispr-hybrid-msi'))
    foreach($d in @($script:Data,$script:Report)+$script:AppRoots+$script:StateRoots){[void][IO.Directory]::CreateDirectory($d)}
    foreach($g in @('{12345678-1234-5678-90AB-CDEF12345678}',$script:Upgrade)+@($script:Codes)){
        Check ((Unpack-Code (Pack-Code $g)) -ieq $g) ('MSI product GUID roundtrip failed: '+$g)
    }
    foreach($text in @('plain','two words','C:\Program Files\whispr VPN\','x"y','C:\trailing\\','',"a`tb")){
        $parts=@(Split-WindowsCommandLine ('host '+(Quote-Argument $text)))
        Check ($parts.Count -eq 2 -and $parts[1] -ceq $text) 'Windows command argument quote/parse roundtrip failed'
    }
    $hostPath=Join-Path $temp 'Windows/pwsh.exe';$ownedScript=Join-Path $script:AppRoots[0] 'Tray.ps1'
    $p=[pscustomobject]@{ProcessId=123456;ExecutablePath=$hostPath;CommandLine=('"'+$hostPath+'" -NoProfile -File "'+$ownedScript+'"')}
    Check (Owned-Process $p) 'Owned script was not recognized'
    $p.CommandLine='pwsh -Command "& '+$ownedScript+'"';Check (-not(Owned-Process $p)) 'Interactive command was accepted as an owned script'
    $p.CommandLine='pwsh -EncodedCommand AAAA';Check (-not(Owned-Process $p)) 'Encoded command was accepted'
    $p.CommandLine='pwsh -File "'+(Join-Path $temp 'other/Tray.ps1')+'"';Check (-not(Owned-Process $p)) 'Unrelated script was accepted'
    foreach($name in @('wireguard.exe','ollama.exe','EmpyrionDedicated.exe','explorer.exe','msiexec.exe','conhost.exe')){
        $p.ExecutablePath=Join-Path $script:AppRoots[0] $name;Check (-not(Owned-Process $p)) ('Protected process was accepted: '+$name)
    }
    $p.ExecutablePath=Join-Path $temp 'other/tor.exe';Check (-not(Owned-Process $p)) 'An unrelated Tor process was accepted'
    Check (-not(Under ($script:AppRoots[0]+'-backup/bin/tor.exe') $script:AppRoots[0])) 'Sibling-prefix path trap accepted'
    $task=[pscustomobject]@{Actions=@([pscustomobject]@{Type=0;Path=$hostPath;Arguments=('-NoProfile -File "'+$ownedScript+'"')})}
    Check (Task-Owned 'whispr-HybridVPN-Autostart-S-1-5-21-123' $task) 'Owned startup task rejected'
    Check (-not(Task-Owned 'n8n-Ollama-Startup' $task)) 'Unrelated startup task accepted'
    # Registry client removal must preserve another product's shared component value.
    $script:ClientValues=@{'OWNCLIENT'='ours';'OTHERCLIENT'='another product'}
    $key=[pscustomobject]@{PSPath='fixture/component'};$key|Add-Member ScriptMethod GetValueNames {return @($script:ClientValues.Keys)}
    function Remove-ItemProperty { [CmdletBinding()]param($LiteralPath,$Name,[switch]$Force);[void]$script:ClientValues.Remove($Name) }
    Check ((Remove-ClientValues $key @('OWNCLIENT')) -eq 1) 'Owned component client was not removed'
    Check ($script:ClientValues.ContainsKey('OTHERCLIENT') -and -not $script:ClientValues.ContainsKey('OWNCLIENT')) 'Foreign shared component client was changed'
    # Windows ACL calls are mocked. Actual filesystem traversal/copy/delete remains real.
    function Protect-Node {param($Item)}
    $live=$script:StateRoots[0];[void][IO.Directory]::CreateDirectory((Join-Path $live 'profiles'))
    [IO.File]::WriteAllText((Join-Path $live 'device-key.json'),'PRIVATE-IDENTITY-SENTINEL')
    [IO.File]::WriteAllText((Join-Path $live 'profiles/fkt1.json'),'FRANKFURT-PROFILE-SENTINEL')
    $quarantine=Join-Path $script:StateRoots[1] 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/state';[void][IO.Directory]::CreateDirectory($quarantine)
    [IO.File]::WriteAllText((Join-Path $quarantine 'device-key.json'),'QUARANTINED-IDENTITY-SENTINEL')
    Save-Identity
    Check (([IO.File]::ReadAllText((Join-Path $script:Report 'identity/device-key.json'))) -ceq 'PRIVATE-IDENTITY-SENTINEL') 'Live private identity was not preserved byte-for-byte'
    Check (([IO.File]::ReadAllText((Join-Path $script:Report 'identity/profiles/fkt1.json'))) -ceq 'FRANKFURT-PROFILE-SENTINEL') 'Saved Frankfurt profile was changed'
    Check ((Get-ChildItem -LiteralPath (Join-Path $script:Report 'alternate-identities') -Filter device-key.json -Recurse).Count -eq 2) 'Quarantined identity was not backed up'
    $tree=$script:AppRoots[0];[void][IO.Directory]::CreateDirectory((Join-Path $tree 'bin'))
    [IO.File]::WriteAllText((Join-Path $tree 'bin/old-runtime.exe'),'old runtime')
    $outside=Join-Path $temp 'unrelated';[void][IO.Directory]::CreateDirectory($outside);[IO.File]::WriteAllText((Join-Path $outside 'KEEP'),'untouched')
    if(-not $IsWindows){[void](New-Item -ItemType SymbolicLink -Path (Join-Path $tree 'junction') -Target $outside)}
    Delete-Tree $tree
    Check (-not(Exists $tree)) 'Owned application tree survived deletion'
    Check ([IO.File]::ReadAllText((Join-Path $outside 'KEEP')) -ceq 'untouched') 'Deletion followed a link into unrelated data'
    $blocked=$false;try{Delete-Tree $outside}catch{$blocked=$true};Check ($blocked -and (Exists $outside)) 'Non-whitelisted deletion was not rejected'
    # Legacy rule recovery is typed by origin and preserves rules disabled before TorVPN.
    $tor=Join-Path $script:Data 'torvpn';[void][IO.Directory]::CreateDirectory($tor)
    @{Profiles=@(@{Name='Private';Outbound='Allow'});SavedRules=@(@{Name='was-enabled';SourceType='Local'},@{Name='runtime';SourceType='Dynamic';PolicyStoreSource='provider'})}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $tor 'firewall-backup.json')
    $script:LocalRules=@([pscustomobject]@{Name='was-enabled';Enabled='False';PolicyStoreSourceType='Local'},[pscustomobject]@{Name='was-disabled';Enabled='False';PolicyStoreSourceType='Local'})
    $script:DynamicRules=@([pscustomobject]@{Name='runtime';Enabled='False';PolicyStoreSourceType='Dynamic';PolicyStoreSource='provider'},[pscustomobject]@{Name='runtime';Enabled='False';PolicyStoreSourceType='Dynamic';PolicyStoreSource='other-provider'})
    function Firewall-Rules {param($PolicyStore='PersistentStore',$Direction,$Action,[switch]$TracePolicyStoreSource);if($PolicyStore -eq 'ActiveStore'){return $script:DynamicRules};return $script:LocalRules}
    function Set-NetFirewallProfile {[CmdletBinding()]param($Name,$DefaultOutboundAction);$script:Outbound=$DefaultOutboundAction}
    function Get-NetFirewallProfile {[CmdletBinding()]param($Name,$PolicyStore);return [pscustomobject]@{DefaultOutboundAction=$script:Outbound}}
    function Enable-NetFirewallRule {[CmdletBinding()]param($InputObject);foreach($r in $InputObject){$r.Enabled='True'}}
    Recover-LegacyFirewall
    Check ($script:LocalRules[0].Enabled -eq 'True' -and $script:LocalRules[1].Enabled -eq 'False') 'Original disabled/local firewall state was not respected'
    Check ($script:DynamicRules[0].Enabled -eq 'True' -and $script:DynamicRules[1].Enabled -eq 'False') 'Dynamic firewall provider matching failed'
    $script:LocalRules[0].Enabled='False'
    function Enable-NetFirewallRule {[CmdletBinding()]param($InputObject)}
    $blocked=$false;try{Recover-LegacyFirewall}catch{$blocked=$true};Check $blocked 'A no-effect restoration was reported successful'
    Check (Exists (Join-Path $tor 'firewall-backup.json')) 'Failed restoration lost its recovery journal'
    # Execute the production orchestration body with OS boundaries mocked.
    $main=$ast.FindAll({param($n) $n -is [Management.Automation.Language.TryStatementAst]},$true)|Where-Object {$_.Extent.Text -like '*Initialize-Paths*'}|Select-Object -Last 1
    $branch=$main.Body.Statements|Where-Object {$_ -is [Management.Automation.Language.IfStatementAst] -and $_.ElseClause -and $_.Extent.Text -like '*Clean-InstallerRegistration*'}|Select-Object -Last 1
    if(-not $branch){throw 'Production reset orchestration could not be located'}
    $body=[scriptblock]::Create($branch.ElseClause.Extent.Text.Trim().Substring(1,$branch.ElseClause.Extent.Text.Trim().Length-2))
    $script:Called=New-Object 'Collections.Generic.List[string]';$script:Roots=@();$script:AppRoots=@();$script:StateRoots=@();$script:Failures.Clear();$script:Reboot=$false;$BootPhase=$false
    function Clean-Tasks {throw 'injected task failure'}
    function Clean-Services {$script:Called.Add('services')}
    function Stop-OwnedProcesses {$script:Called.Add('processes')}
    function Save-Identity {$script:Called.Add('identity')}
    function Recover-Guard {$script:Called.Add('guard')}
    function Recover-LegacyFirewall {$script:Called.Add('firewall')}
    function Recover-LegacyAudit {}
    function Clean-Adapters {}
    function Clean-FirewallDNS {}
    function Clean-ShortcutsAndStartup {}
    function Try-NormalRemoval {$script:Called.Add('native-msi')}
    function Clean-InstallerRegistration {$script:Called.Add('registrations')}
    function Process-List {return @()}
    function Owned-Adapters {return @()}
    function Service-List {return @()}
    function Save-Report {param($Result);$script:Result=$Result}
    function Schedule-BootCleanup {$script:Called.Add('boot-retry')}
    function New-Object {
        [CmdletBinding()]param([string]$TypeName,[string]$ComObject)
        if($ComObject -eq 'Schedule.Service'){$s=[pscustomobject]@{};$s|Add-Member ScriptMethod Connect {};$s|Add-Member ScriptMethod GetFolder {param($p);return $null};return $s}
        Microsoft.PowerShell.Utility\New-Object @PSBoundParameters
    }
    function Task-List {param($Folder);return @()}
    $msiLock=$null;$ownsMsiLock=$false
    try{. $body}finally{if($ownsMsiLock){$msiLock.ReleaseMutex()};if($msiLock){$msiLock.Dispose()}}
    Check ('services' -in $script:Called -and 'guard' -in $script:Called -and 'registrations' -in $script:Called) 'One failed stage suppressed independent cleanup'
    Check ($script:Result -eq 'attention-required' -and 'boot-retry' -in $script:Called) 'Incomplete cleanup was reported clean or lacked a reboot retry'
    $script:Failures.Clear();$script:Reboot=$false;$script:Called.Clear()
    function Clean-Tasks {}
    $msiLock=$null;$ownsMsiLock=$false
    try{. $body}finally{if($ownsMsiLock){$msiLock.ReleaseMutex()};if($msiLock){$msiLock.Dispose()}}
    Check ($script:Result -eq 'clean' -and 'boot-retry' -notin $script:Called) 'Successful cleanup was not reported clean or scheduled an unnecessary retry'
    $script:Failures.Clear();$script:Reboot=$false;$script:Called.Clear()
    function Save-Identity {throw 'injected identity backup failure'}
    $blocked=$false;$msiLock=$null;$ownsMsiLock=$false
    try{. $body}catch{$blocked=$true}finally{if($ownsMsiLock){$msiLock.ReleaseMutex()};if($msiLock){$msiLock.Dispose()}}
    Check ($blocked -and 'registrations' -notin $script:Called -and 'native-msi' -notin $script:Called) 'Identity backup failure did not stop destructive cleanup'
    Write-Host ('PASS: '+$script:TestCount+' recovery contract assertions. Windows ACL/CIM/SCM/MSI/PnP execution remains untested.')
}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Recurse -Force}}
