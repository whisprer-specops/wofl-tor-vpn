@echo off
setlocal
cd /d "%~dp0"
title Restore original whispr device identity
set "WHISPR_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "WHISPR_POWERSHELL=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
echo Restore original whispr device identity
echo Windows may request administrator approval.
"%WHISPR_POWERSHELL%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Reset-WhisprVPN.ps1" -RestoreIdentity
set "WHISPR_RESULT=%ERRORLEVEL%"
echo.
if "%WHISPR_RESULT%"=="0" echo Completed successfully.
if "%WHISPR_RESULT%"=="2" echo Attention required. Restart Windows once if requested, then run AUDIT-ONLY.cmd.
if not "%WHISPR_RESULT%"=="0" if not "%WHISPR_RESULT%"=="2" echo The operation stopped. Read the error above and the recovery report.
echo Reports: %PUBLIC%\Documents\whispr-VPN-Recovery
echo.
pause
exit /b %WHISPR_RESULT%
