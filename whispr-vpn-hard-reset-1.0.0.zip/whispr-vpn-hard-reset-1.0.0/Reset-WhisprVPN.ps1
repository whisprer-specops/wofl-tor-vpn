#requires -Version 5.1
[CmdletBinding()]
param([switch]$AuditOnly,[switch]$RestoreIdentity,[switch]$BootPhase,[switch]$FunctionsOnly)
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'
$script:Failures=New-Object 'Collections.Generic.List[string]'
$script:Events=New-Object 'Collections.Generic.List[object]'
$script:Roots=@();$script:AppRoots=@();$script:StateRoots=@();$script:Report=$null;$script:Reboot=$false
$script:Codes=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach($code in @('{8EECFA30-9E1C-439B-AC91-C6AA86359808}','{B3CB5E52-AFB6-455A-B2DF-869111A0D101}','{D8720DE2-B1A9-46C3-BF9F-F43314B37A02}','{21A8F5D7-2682-45C8-B2DE-92C9D8699A11}')){[void]$script:Codes.Add($code)}
$script:Upgrade='{260C4308-9E2C-4C71-B65B-05199CB8262E}'
$script:GuardHash='44863A7FAF76F8877681283F6A16E4CB02A3C051117439345C469364A4306EA6'
function Field($Value,[string]$Name){if($null -eq $Value){return $null};$p=$Value.PSObject.Properties[$Name];if($p){return $p.Value};return $null}
function Record([string]$Kind,[string]$Text){
    $script:Events.Add([pscustomobject]@{At=[DateTime]::UtcNow.ToString('o');Kind=$Kind;Message=$Text})
    Write-Host ('['+$Kind+'] '+$Text)
    if($script:Report){Add-Content -LiteralPath (Join-Path $script:Report 'reset.log') -Value ((Get-Date -Format o)+' ['+$Kind+'] '+$Text) -Encoding UTF8}
}
function Attempt([string]$Label,[scriptblock]$Action){Record 'WORK' $Label;try{& $Action}catch{$script:Failures.Add($Label);Record 'FAILED' ($Label+': '+$_.Exception.Message)}}
function Canonical([string]$Path){return [IO.Path]::GetFullPath($Path).TrimEnd([char[]]'\/')}
function Under([string]$Path,[string]$Root){if(-not $Path -or -not $Root){return $false};return (Canonical $Path).StartsWith((Canonical $Root)+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)}
function Is-AppPath([string]$Path){foreach($r in $script:AppRoots){if((Canonical $Path) -ieq (Canonical $r) -or (Under $Path $r)){return $true}};return $false}
function Assert-Root([string]$Path){if((Canonical $Path) -in @($script:Roots|ForEach-Object {Canonical $_})){return};throw 'Refusing a directory outside the explicit VPN cleanup roots.'}
function Exists([string]$Path){return $null -ne (Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue)}
function Is-Link($Item){return [bool]($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)}
function Assert-NoAncestorLinks([string]$Path){
    $item=Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    while($item){if(Is-Link $item){throw 'A path contains a junction/symlink; its target was not followed.'};$item=if($item -is [IO.FileInfo]){$item.Directory}else{$item.Parent}}
}
function Protect-Node($Item){
    if(Is-Link $Item){throw 'Permissions will not be changed through a link.'}
    $directory=$Item -is [IO.DirectoryInfo]
    $acl=if($directory){New-Object Security.AccessControl.DirectorySecurity}else{New-Object Security.AccessControl.FileSecurity}
    $acl.SetAccessRuleProtection($true,$false)
    $acl.SetOwner([Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))
    foreach($sidText in @('S-1-5-18','S-1-5-32-544')){
        $sid=[Security.Principal.SecurityIdentifier]::new($sidText)
        $rule=if($directory){[Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow')}else{[Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','Allow')}
        [void]$acl.AddAccessRule($rule)
    }
    try{Set-Acl -LiteralPath $Item.FullName -AclObject $acl -ErrorAction Stop}catch{
        & "$env:SystemRoot/System32/takeown.exe" /F $Item.FullName /A | Out-Null
        if($LASTEXITCODE -ne 0){throw 'Could not take ownership of an app-owned item.'}
        Set-Acl -LiteralPath $Item.FullName -AclObject $acl -ErrorAction Stop
    }
}
function Protect-Tree([string]$Root){
    if(-not(Exists $Root)){return};$stack=New-Object 'Collections.Generic.Stack[string]';$stack.Push($Root)
    while($stack.Count){$p=$stack.Pop();$item=Get-Item -LiteralPath $p -Force;if(Is-Link $item){continue};Protect-Node $item;if($item -is [IO.DirectoryInfo]){foreach($child in Get-ChildItem -LiteralPath $p -Force){$stack.Push($child.FullName)}}}
}
function Delete-Tree([string]$Root){
    Assert-Root $Root;if(-not(Exists $Root)){return}
    # Explicit postorder traversal: never recurse into junctions, symlinks or mount points.
    $stack=New-Object 'Collections.Generic.Stack[object]';$stack.Push(@($Root,$false))
    while($stack.Count){
        $entry=$stack.Pop();$item=Get-Item -LiteralPath $entry[0] -Force -ErrorAction Stop
        if(Is-Link $item){if($item -is [IO.DirectoryInfo]){[IO.Directory]::Delete($item.FullName,$false)}else{[IO.File]::Delete($item.FullName)};continue}
        if($item -is [IO.DirectoryInfo]){
            if($entry[1]){[IO.Directory]::Delete($item.FullName,$false)}else{Protect-Node $item;$stack.Push(@($item.FullName,$true));foreach($child in Get-ChildItem -LiteralPath $item.FullName -Force){$stack.Push(@($child.FullName,$false))}}
        }else{Protect-Node $item;$item.Attributes=[IO.FileAttributes]::Normal;[IO.File]::Delete($item.FullName)}
    }
    Record 'REMOVED' $Root
}
function Read-Record([string]$Path){Assert-NoAncestorLinks $Path;$f=Get-Item -LiteralPath $Path -Force;if($f -isnot [IO.FileInfo] -or $f.Length -gt 16777216){throw 'Unexpected recovery record type/size.'};return Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json}
function Pack-Code([string]$Code){
    if($Code -notmatch '^\{?[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}?$'){throw 'Invalid product GUID'}
    $s=$Code.Trim('{}').Replace('-','').ToUpperInvariant();$out=''
    foreach($part in @($s.Substring(0,8),$s.Substring(8,4),$s.Substring(12,4))){$chars=$part.ToCharArray();[Array]::Reverse($chars);$out+=(-join $chars)}
    for($i=16;$i -lt 32;$i+=2){$out+=$s[$i+1];$out+=$s[$i]};return $out
}
function Unpack-Code([string]$Packed){
    if($Packed -notmatch '^[0-9a-fA-F]{32}$'){throw 'Invalid packed product GUID'}
    $out='';foreach($part in @($Packed.Substring(0,8),$Packed.Substring(8,4),$Packed.Substring(12,4))){$chars=$part.ToCharArray();[Array]::Reverse($chars);$out+=(-join $chars)}
    for($i=16;$i -lt 32;$i+=2){$out+=$Packed[$i+1];$out+=$Packed[$i]}
    return '{'+$out.Substring(0,8)+'-'+$out.Substring(8,4)+'-'+$out.Substring(12,4)+'-'+$out.Substring(16,4)+'-'+$out.Substring(20,12)+'}'
}
function Split-WindowsCommandLine([string]$Text){
    $result=New-Object 'Collections.Generic.List[string]';$i=0
    while($i -lt $Text.Length){
        while($i -lt $Text.Length -and [char]::IsWhiteSpace($Text[$i])){$i++};if($i -eq $Text.Length){break}
        $arg=New-Object Text.StringBuilder;$quoted=$false
        while($i -lt $Text.Length){
            if(-not $quoted -and [char]::IsWhiteSpace($Text[$i])){break}
            $slashes=0;while($i -lt $Text.Length -and $Text[$i] -eq '\'){$slashes++;$i++}
            if($i -lt $Text.Length -and $Text[$i] -eq '"'){
                [void]$arg.Append(('\'*[int][Math]::Floor($slashes/2)))
                if($slashes%2){[void]$arg.Append('"')}elseif($quoted -and $i+1 -lt $Text.Length -and $Text[$i+1] -eq '"'){[void]$arg.Append('"');$i++}else{$quoted=-not $quoted};$i++
            }else{[void]$arg.Append(('\'*$slashes));if($i -lt $Text.Length){[void]$arg.Append($Text[$i]);$i++}}
        }
        if($quoted){return @()};$result.Add($arg.ToString())
    }
    return $result.ToArray()
}
function Quote-Argument([string]$Text){return '"'+[regex]::Replace($Text,'(\\*)"','$1$1\"').TrimEnd([char]'\')+('\'*(2*([regex]::Match($Text,'\\*$').Length)))+'"'}
function Owned-Process($p){
    if([int]$p.ProcessId -le 4 -or [int]$p.ProcessId -eq $PID -or -not $p.ExecutablePath){return $false}
    $name=[IO.Path]::GetFileName([string]$p.ExecutablePath)
    if($name -in @('explorer.exe','cmd.exe','conhost.exe','svchost.exe','lsass.exe','services.exe','winlogon.exe','msiexec.exe','WindowsTerminal.exe')){return $false}
    if((Is-AppPath $p.ExecutablePath) -and $name -in @('pwsh.exe','whispr.exe','whispr-vpn-guard.exe','sing-box.exe','tor.exe','torvpn-svc.exe','torvpn-tray.exe','tun2socks.exe','whispr-vpn-1.0.3-setup.exe','whispr-vpn-1.0.2-setup.exe')){return $true}
    if($name -notin @('pwsh.exe','powershell.exe')){return $false}
    $tokens=@(Split-WindowsCommandLine ([string]$p.CommandLine))
    for($i=1;$i -lt $tokens.Count;$i++){
        if($tokens[$i] -in @('-Command','-c','-EncodedCommand','-e','-ec')){return $false}
        if($tokens[$i] -in @('-File','-f')){
            if($i+1 -ge $tokens.Count){return $false};$path=$tokens[$i+1]
            if(Is-AppPath $path){return $true}
            if([IO.Path]::GetFileName($path) -eq 'Setup.ps1' -and $script:Data -and (Under $path (Join-Path $script:Data 'whispr-vpn-setup'))){return $true}
            return $false
        }
    }
    return $false
}
function Process-List {return @(Get-CimInstance Win32_Process -OperationTimeoutSec 20|Where-Object {Owned-Process $_})}
function Stop-OwnedProcesses {
    for($pass=0;$pass -lt 12;$pass++){
        $items=@(Process-List);if(-not $items.Count){return}
        foreach($r in $items){
            Attempt ('Stop process '+$r.ProcessId) {
                Assert-NoAncestorLinks ([string]$r.ExecutablePath)
                $p=[Diagnostics.Process]::GetProcessById([int]$r.ProcessId)
                try{
                    # Open/cache a handle before checking creation time and image. PID reuse does not retarget this object.
                    [void]$p.Handle
                    if($p.HasExited){return}
                    if($p.MainModule.FileName -ine [string]$r.ExecutablePath -or $p.StartTime.ToUniversalTime().ToFileTimeUtc() -ne ([datetime]$r.CreationDate).ToUniversalTime().ToFileTimeUtc()){throw 'Process identity changed; target was not killed.'}
                    $p.Kill();if(-not $p.WaitForExit(10000)){throw 'Process did not exit'};Record 'STOPPED' ('Verified '+[IO.Path]::GetFileName([string]$r.ExecutablePath)+' PID '+$r.ProcessId)
                }finally{$p.Dispose()}
            }
        }
        Start-Sleep -Milliseconds 200
    }
    if(@(Process-List).Count){throw 'Verified whispr processes are still restarting.'}
}
function Task-Owned([string]$Name,$Definition){
    if($Name -notmatch '^(?:whispr[- _](?:Hybrid[- _]?)?VPN|TorVPN)(?:[-_ ].*)?$'){return $false}
    foreach($a in $Definition.Actions){
        if($a.Type -ne 0){continue}
        if(Is-AppPath ([string]$a.Path)){return $true}
        $p=[pscustomobject]@{ProcessId=999999;ExecutablePath=[string]$a.Path;CommandLine=([string]$a.Path+' '+[string]$a.Arguments)}
        if(Owned-Process $p){return $true}
    }
    return $false
}
function Task-List($Folder){
    foreach($t in $Folder.GetTasks(1)){
        if([string]$t.Name -notmatch '^(?:whispr[- _](?:Hybrid[- _]?)?VPN|TorVPN)(?:[-_ ].*)?$'){continue}
        if(Task-Owned ([string]$t.Name) $t.Definition){[pscustomobject]@{Folder=$Folder;Task=$t;Name=[string]$t.Name;Path=[string]$t.Path}}
    }
    foreach($f in $Folder.GetFolders(0)){Task-List $f}
}
function Clean-Tasks([switch]$ReadOnly){
    $s=New-Object -ComObject Schedule.Service;$s.Connect()
    foreach($t in @(Task-List ($s.GetFolder('\')))){
        if($ReadOnly){Record 'FOUND' ('Task '+$t.Path);continue}
        Attempt ('Remove task '+$t.Path) {$t.Task.Enabled=$false;try{$t.Task.Stop(0)}catch{if($t.Task.State -eq 4){throw}};$t.Folder.DeleteTask($t.Name,0);Record 'REMOVED' ('Task '+$t.Path)}
    }
}
function Service-List {
    foreach($s in @(Get-CimInstance Win32_Service -OperationTimeoutSec 20)){
        $tokens=@(Split-WindowsCommandLine ([string]$s.PathName));if(-not $tokens.Count){continue}
        if($s.Name -match '^(?:TorVPN|whisprHybridVPN|whispr-HybridVPN|whisprVPN)$' -and (Is-AppPath $tokens[0])){$s}
    }
}
function Clean-Services([switch]$ReadOnly){
    foreach($s in @(Service-List)){
        if($ReadOnly){Record 'FOUND' ('Service '+$s.Name);continue}
        Attempt ('Remove service '+$s.Name) {
            Set-Service -Name $s.Name -StartupType Disabled
            & "$env:SystemRoot/System32/sc.exe" stop $s.Name|Out-Null
            & "$env:SystemRoot/System32/sc.exe" delete $s.Name|Out-Null
            if($LASTEXITCODE -notin @(0,1060,1072)){throw 'SCM deletion failed'}
            if($LASTEXITCODE -eq 1072){$script:Reboot=$true};Record 'REMOVED' ('Service '+$s.Name)
        }
    }
}
function Recover-Guard {
    $guard=Join-Path $PSScriptRoot 'tools/whispr-vpn-guard.exe';Assert-NoAncestorLinks $guard
    if((Get-FileHash -LiteralPath $guard -Algorithm SHA256).Hash -ine $script:GuardHash){throw 'Bundled Rust guard failed SHA-256 verification'}
    function Run-Guard([string]$Command){
        $start=[Diagnostics.ProcessStartInfo]::new($guard);$start.Arguments=$Command;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
        $p=[Diagnostics.Process]::Start($start)
        try{$out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync();if(-not $p.WaitForExit(20000)){try{$p.Kill()}catch{};throw 'WFP recovery timed out; its own child process was stopped.'};if($p.ExitCode -ne 0){throw 'Rust guard operation failed'};[void]$err.GetAwaiter().GetResult();return $out.GetAwaiter().GetResult().Trim()}finally{$p.Dispose()}
    }
    Record 'GUARD' (Run-Guard 'recover')
    $status=Run-Guard 'status';if($status -cne 'DISARMED'){throw 'Owned WFP protection is not DISARMED'}
    Record 'VERIFIED' 'Owned WFP provider disarmed.'
}
function Copy-Identity([string]$State,[string]$Identity){
    [void][IO.Directory]::CreateDirectory($Identity);Protect-Node (Get-Item -LiteralPath $Identity)
    foreach($name in @('device-key.json','peer.json','group-catalog.json','profiles')){
        $path=Join-Path $State $name;if(-not(Exists $path)){continue}
        Assert-NoAncestorLinks $path
        if((Get-Item -LiteralPath $path) -is [IO.DirectoryInfo]){
            [void][IO.Directory]::CreateDirectory((Join-Path $Identity $name))
            foreach($file in Get-ChildItem -LiteralPath $path -File -Force){if(Is-Link $file){throw 'Linked identity file was not copied'};Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $Identity $name)}
        }else{Copy-Item -LiteralPath $path -Destination (Join-Path $Identity $name)}
    }
    Protect-Tree $Identity
}
function Save-Identity {
    $candidates=New-Object 'Collections.Generic.List[string]'
    foreach($root in $script:StateRoots){
        if([IO.Path]::GetFileName($root) -notin @('whispr-hybrid','whispr-hybrid-msi','whispr-vpn-desktop') -or -not(Exists $root)){continue}
        if(Is-Link (Get-Item -LiteralPath $root -Force)){Record 'NOTE' 'A linked state root was excluded from identity backup; its link target is outside cleanup.';continue}
        Assert-NoAncestorLinks $root
        Protect-Tree $root;$pending=New-Object 'Collections.Generic.Stack[string]';$pending.Push($root)
        while($pending.Count){$p=$pending.Pop();if(Exists (Join-Path $p 'device-key.json')){$candidates.Add($p)}
            foreach($dir in Get-ChildItem -LiteralPath $p -Directory -Force){if(-not(Is-Link $dir)){$pending.Push($dir.FullName)}}
        }
    }
    if(-not $candidates.Count){Record 'BACKUP' 'No saved device-key file found in live state or quarantined state backups.';return}
    $live=Join-Path $script:Data 'whispr-hybrid';$number=0;$primary=$false
    foreach($state in $candidates){
        $number++;$destination=Join-Path $script:Report ('alternate-identities/'+$number)
        Copy-Identity $state $destination
        if((Canonical $state) -ieq (Canonical $live)){Copy-Identity $state (Join-Path $script:Report 'identity');$primary=$true}
    }
    if(-not $primary){
        $same=$true;$first=$null
        foreach($state in $candidates){
            try{$key=Read-Record (Join-Path $state 'device-key.json');$pair=[string](Field $key 'PrivateKey')+'|'+[string](Field $key 'PublicKey');if(-not $first){$first=$pair}elseif($pair -cne $first){$same=$false}}catch{$same=$false}
        }
        if($candidates.Count -eq 1 -or $same){Copy-Identity $candidates[0] (Join-Path $script:Report 'identity')}
        else{Record 'NOTE' 'Multiple distinct quarantined identities were saved. Automatic restore will not guess which device identity you want.'}
    }
    Record 'BACKUP' ('Saved '+$candidates.Count+' device identity set(s), including quarantined MSI backups; key contents were not logged.')
}
function Firewall-Rules {
    param([string]$PolicyStore='PersistentStore',[string]$Direction,[string]$Action,[switch]$TracePolicyStoreSource)
    $query=@{PolicyStore=$PolicyStore;ErrorAction='Stop'}
    foreach($name in @('Direction','Action','TracePolicyStoreSource')){if($PSBoundParameters.ContainsKey($name)){$query[$name]=$PSBoundParameters[$name]}}
    try{Get-NetFirewallRule @query}catch{if($_.CategoryInfo.Category -eq [Management.Automation.ErrorCategory]::ObjectNotFound -and $_.FullyQualifiedErrorId -match '^CmdletizationQuery_NotFound'){return};throw}
}
function Recover-LegacyFirewall {
    $state=Join-Path $script:Data 'torvpn';$path=Join-Path $state 'firewall-backup.json'
    if(-not(Exists $path)){return};$saved=Read-Record $path
    Copy-Item -LiteralPath $path -Destination (Join-Path $script:Report 'legacy-firewall-backup.json')
    foreach($p in @($saved.Profiles)){
        if($p.Name -notin @('Domain','Private','Public') -or $p.Outbound -notin @('Allow','Block','NotConfigured')){throw 'Unsupported saved firewall profile'}
        Set-NetFirewallProfile -Name $p.Name -DefaultOutboundAction $p.Outbound -ErrorAction Stop
    }
    $rules=if($null -ne (Field $saved 'SavedRules')){@($saved.SavedRules)}else{@($saved.AllowRules|ForEach-Object {[pscustomobject]@{Name=$_;SourceType='Local';PolicyStoreSource='PersistentStore'}})}
    $local=@(Firewall-Rules -Direction Outbound -Action Allow)
    $dynamic=@();if(@($rules|Where-Object SourceType -eq 'Dynamic').Count){$dynamic=@(Firewall-Rules -PolicyStore ActiveStore -TracePolicyStoreSource -Direction Outbound -Action Allow|Where-Object PolicyStoreSourceType -eq 'Dynamic')}
    $index=@{};foreach($rule in $local){$index['Local|'+$rule.Name]=@($rule)};foreach($rule in $dynamic){$key='Dynamic|'+$rule.Name+'|'+[string]$rule.PolicyStoreSource;$index[$key]=@($index[$key])+@($rule)}
    $restore=New-Object 'Collections.Generic.List[object]'
    foreach($r in $rules){
        if($r.SourceType -eq 'Local'){$key='Local|'+$r.Name}elseif($r.SourceType -eq 'Dynamic'){$key='Dynamic|'+$r.Name+'|'+[string]$r.PolicyStoreSource}else{throw 'Unknown saved firewall rule origin'}
        if($index.ContainsKey($key)){foreach($rule in $index[$key]){if($rule -and [string]$rule.Enabled -ne 'True'){$restore.Add($rule)}}}
    }
    if($restore.Count){Enable-NetFirewallRule -InputObject $restore.ToArray() -ErrorAction Stop|Out-Null}
    foreach($p in @($saved.Profiles)){
        $profile=Get-NetFirewallProfile -Name $p.Name -PolicyStore PersistentStore -ErrorAction Stop
        if([string]$profile.DefaultOutboundAction -ine [string]$p.Outbound){throw 'Legacy firewall profile restoration did not take effect; journal retained.'}
    }
    $verify=@(Firewall-Rules -Direction Outbound -Action Allow)
    if(@($rules|Where-Object SourceType -eq 'Dynamic').Count){$verify+=@(Firewall-Rules -PolicyStore ActiveStore -TracePolicyStoreSource -Direction Outbound -Action Allow|Where-Object PolicyStoreSourceType -eq 'Dynamic')}
    $remaining=@{};foreach($r in $rules){$key=if($r.SourceType -eq 'Local'){'Local|'+$r.Name}else{'Dynamic|'+$r.Name+'|'+[string]$r.PolicyStoreSource};$remaining[$key]=$true}
    foreach($rule in $verify){$key=if([string](Field $rule 'PolicyStoreSourceType') -eq 'Dynamic'){'Dynamic|'+$rule.Name+'|'+[string]$rule.PolicyStoreSource}else{'Local|'+$rule.Name};if($remaining.ContainsKey($key) -and [string]$rule.Enabled -ne 'True'){throw 'A saved firewall allow rule is still disabled; journal retained.'}}
    Record 'RESTORED' 'Legacy TorVPN firewall profile defaults and recorded Local/Dynamic allow rules.'
}
function Recover-LegacyAudit {
    $path=Join-Path $script:Data 'torvpn/audit-backup.json';if(-not(Exists $path)){return};$saved=Read-Record $path
    $flags=[int]$saved.OriginalFlags;if($flags -lt 0 -or $flags -gt 3){throw 'Invalid saved audit flags'}
    Copy-Item -LiteralPath $path -Destination (Join-Path $script:Report 'legacy-audit-backup.json')
    $success=if($flags -band 1){'/success:enable'}else{'/success:disable'};$failure=if($flags -band 2){'/failure:enable'}else{'/failure:disable'}
    & "$env:SystemRoot/System32/auditpol.exe" /set '/subcategory:{0CCE9226-69AE-11D9-BED3-505054503030}' $success $failure|Out-Null
    if($LASTEXITCODE -ne 0){throw 'Saved audit policy restoration failed'};Record 'RESTORED' 'Recorded legacy WFP audit settings.'
}
function Clean-FirewallDNS {
    foreach($rule in @(Firewall-Rules)){
        if($rule.Group -in @('TORVPN','whispr Hybrid VPN','whispr-HybridVPN') -or $rule.DisplayName -match '^(?:TORVPN |whispr Hybrid VPN |whispr-HybridVPN )'){
            $rule|Remove-NetFirewallRule -ErrorAction Stop;Record 'REMOVED' ('Firewall rule '+$rule.Name)
        }
    }
    foreach($r in @(Get-DnsClientNrptRule -ErrorAction Stop)){
        if($r.DisplayName -in @('TORVPN Default','whispr Hybrid VPN','whispr-HybridVPN')){Remove-DnsClientNrptRule -Name $r.Name -Force -ErrorAction Stop;Record 'REMOVED' ('Owned DNS rule '+$r.Name)}
    }
    Clear-DnsClientCache
}
function Owned-Adapters {
    foreach($a in @(Get-NetAdapter -IncludeHidden -ErrorAction Stop)){
        if($a.Name -notin @('whispr-hybrid','torvpn')){continue}
        $ips=@(Get-NetIPAddress -InterfaceIndex $a.ifIndex -ErrorAction SilentlyContinue|Select-Object -ExpandProperty IPAddress)
        $description=[string]$a.InterfaceDescription
        if($description -match '(?i)wintun|sing-box|tun2socks|torvpn' -or '172.31.249.1' -in $ips -or 'fd89:77:71::1' -in $ips -or '10.86.1.2' -in $ips){$a}else{throw 'A named VPN adapter has an unverified identity; it was not removed.'}
    }
}
function Clean-Adapters {
    # Remove route entries only on positively identified app adapters, never a physical/WireGuard default route.
    foreach($a in @(Owned-Adapters)){
        foreach($store in @('ActiveStore','PersistentStore')){foreach($r in @(Get-NetRoute -InterfaceIndex $a.ifIndex -PolicyStore $store -ErrorAction SilentlyContinue)){$r|Remove-NetRoute -Confirm:$false -ErrorAction Stop}}
        $guid=([string]$a.InterfaceGuid).Trim('{}')
        $devices=@(Get-CimInstance Win32_NetworkAdapter -OperationTimeoutSec 20|Where-Object {([string]$_.GUID).Trim('{}') -ieq $guid})
        if($devices.Count -ne 1 -or -not $devices[0].PNPDeviceID){throw 'Cannot identify the exact owned PnP instance'}
        & "$env:SystemRoot/System32/pnputil.exe" /remove-device ([string]$devices[0].PNPDeviceID)|Out-Null
        if($LASTEXITCODE -eq 3010){$script:Reboot=$true}elseif($LASTEXITCODE -ne 0){throw 'Owned PnP device removal failed'}
        Record 'REMOVED' ('Owned tunnel '+$a.Name+' '+$guid)
    }
    foreach($device in @(Get-PnpDevice -Class Net -ErrorAction Stop)){
        if($device.FriendlyName -match '^(?:whispr-hybrid|torvpn)(?: Tunnel)?(?: #[0-9]+)?$'){
            & "$env:SystemRoot/System32/pnputil.exe" /remove-device ([string]$device.InstanceId)|Out-Null
            if($LASTEXITCODE -eq 3010){$script:Reboot=$true}elseif($LASTEXITCODE -ne 0){throw 'Owned phantom adapter could not be removed'}
            Record 'REMOVED' ('Owned PnP adapter '+$device.FriendlyName)
        }
    }
    $path=Join-Path $script:Data 'torvpn/routes.json'
    if(Exists $path){
        $saved=Read-Record $path
        foreach($r in @(Field $saved 'AddedRoutes')){
            if(-not $r){continue}
            # Legacy added relay bypasses are /32 host routes with an exact saved gateway/interface tuple.
            if([string]$r.DestinationPrefix -notmatch '^([0-9]{1,3}\.){3}[0-9]{1,3}/32$'){continue}
            foreach($route in @(Get-NetRoute -DestinationPrefix $r.DestinationPrefix -InterfaceIndex ([int]$r.InterfaceIndex) -PolicyStore ActiveStore -ErrorAction SilentlyContinue|Where-Object NextHop -eq $r.NextHop)){$route|Remove-NetRoute -Confirm:$false -ErrorAction Stop}
        }
    }
}
function Discover-Products {
    $packed=Pack-Code $script:Upgrade
    foreach($base in $script:InstallerBases){
        $key=Join-Path $base ('UpgradeCodes/'+$packed)
        if(Test-Path -LiteralPath $key){$k=Get-Item -LiteralPath $key;foreach($v in $k.GetValueNames()){if($v -match '^[A-Fa-f0-9]{32}$'){[void]$script:Codes.Add((Unpack-Code $v))}}}
    }
}
function Backup-Registry([string]$Path){
    if(-not(Test-Path -LiteralPath $Path)){return}
    $native=($Path -replace '^(?:Microsoft[.]PowerShell[.]Core\\)?Registry::','').Replace('/','\')
    $id=[guid]::NewGuid().ToString('N');$out=Join-Path $script:Report ('registry-'+$id+'.reg')
    & "$env:SystemRoot/System32/reg.exe" export $native $out /y|Out-Null
    if($LASTEXITCODE -ne 0){throw 'Registry export failed; that key was not removed'}
}
function Delete-Reg([string]$Path){if(Test-Path -LiteralPath $Path){Backup-Registry $Path;Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop;Record 'REMOVED' $Path}}
function Remove-ClientValues($Key,[string[]]$Clients){
    $removed=0
    foreach($name in @($Key.GetValueNames())){if($name -in $Clients){Remove-ItemProperty -LiteralPath $Key.PSPath -Name $name -Force -ErrorAction Stop;$removed++}}
    return $removed
}
function Clean-InstallerRegistration {
    $packed=@($script:Codes|ForEach-Object {Pack-Code $_})
    # Export exact product registrations first. Do not enumerate Win32_Product or invoke its repair side effects.
    foreach($code in $script:Codes){
        foreach($base in $script:UninstallBases){Delete-Reg (Join-Path $base $code)}
    }
    foreach($base in $script:UninstallBases){
        if(-not(Test-Path -LiteralPath $base)){continue}
        foreach($key in Get-ChildItem -LiteralPath $base){
            $entry=Get-ItemProperty -LiteralPath $key.PSPath
            $name=[string](Field $entry 'DisplayName');$where=[string](Field $entry 'InstallLocation')
            if($name -match '^(?:TorVPN|whispr (?:Hybrid )?VPN)(?:\s+v?[0-9].*)?$' -and $where -and (Is-AppPath $where)){Delete-Reg $key.PSPath}
        }
    }
    foreach($base in $script:InstallerBases){
        foreach($p in $packed){foreach($branch in @('Products','Features')){Delete-Reg (Join-Path $base ($branch+'/'+$p))}}
        $upgrades=Join-Path $base 'UpgradeCodes'
        if(Test-Path -LiteralPath $upgrades){foreach($k in Get-ChildItem -LiteralPath $upgrades){$hits=@($k.GetValueNames()|Where-Object {$_ -in $packed});if(-not $hits.Count){continue};Backup-Registry $k.PSPath;[void](Remove-ClientValues $k $packed);if($k.ValueCount -eq 0 -and $k.SubKeyCount -eq 0){Remove-Item -LiteralPath $k.PSPath -Force}}}
    }
    $userdata='Registry::HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows/CurrentVersion/Installer/UserData'
    if(Test-Path -LiteralPath $userdata){foreach($sid in Get-ChildItem -LiteralPath $userdata){
        foreach($p in $packed){Delete-Reg (Join-Path $sid.PSPath ('Products/'+$p))}
        $components=Join-Path $sid.PSPath 'Components';if(-not(Test-Path -LiteralPath $components)){continue}
        foreach($entry in Get-ChildItem -LiteralPath $components){
            $hits=@($entry.GetValueNames()|Where-Object {$_ -in $packed});if(-not $hits.Count){continue}
            Backup-Registry $entry.PSPath
            # Delete only these products' client values. Keep other products' shared component clients.
            [void](Remove-ClientValues $entry $packed)
            if($entry.ValueCount -eq 0 -and $entry.SubKeyCount -eq 0){Remove-Item -LiteralPath $entry.PSPath -Force}
        }
    }}
    foreach($name in @('VPN Desktop','Hybrid VPN')){Delete-Reg ('Registry::HKEY_LOCAL_MACHINE/Software/whispr.dev/'+$name)}
}
function Try-NormalRemoval {
    foreach($code in $script:Codes){
        $found=$false;foreach($base in $script:UninstallBases){if(Test-Path -LiteralPath (Join-Path $base $code)){$found=$true}}
        if(-not $found){continue}
        $log=Join-Path $script:Report ('msi-'+$code.Trim('{}')+'.log')
        $args='/x '+$code+' /qn /norestart REBOOT=ReallySuppress UPGRADINGPRODUCTCODE=WHISPR_RECOVERY WHISPR_SETUP_MANAGED=1 LAUNCH_APP=0 /L*v '+(Quote-Argument $log)
        Record 'MSI' ('Trying normal removal of '+$code)
        $p=Start-Process -FilePath "$env:SystemRoot/System32/msiexec.exe" -ArgumentList $args -PassThru
        try{
            if(-not $p.WaitForExit(120000)){throw 'This MSI did not finish. Its installer was not killed. Let Windows Installer finish before rerunning the tool.'}
            if($p.ExitCode -eq 1618){throw 'Another Windows installation is active; registry cleanup was not started.'}
            if($p.ExitCode -eq 3010){$script:Reboot=$true}
            Record 'MSI' ('Exit '+$p.ExitCode+' for '+$code+'; exact orphan-registration cleanup follows.')
        }finally{$p.Dispose()}
    }
}
function Clean-ShortcutsAndStartup {
    $shell=New-Object -ComObject WScript.Shell
    try{
        foreach($dir in $script:ShortcutDirs){if(-not(Exists $dir)){continue};Assert-NoAncestorLinks $dir
            foreach($f in Get-ChildItem -LiteralPath $dir -Filter '*.lnk' -File -Force -Recurse -ErrorAction SilentlyContinue){
                if(Is-Link $f){continue};$link=$shell.CreateShortcut($f.FullName)
                $r=[pscustomobject]@{ProcessId=999999;ExecutablePath=$link.TargetPath;CommandLine=($link.TargetPath+' '+$link.Arguments)}
                if((Is-AppPath $link.TargetPath) -or (Owned-Process $r)){Assert-NoAncestorLinks $f.FullName;Remove-Item -LiteralPath $f.FullName -Force;Record 'REMOVED' ('Shortcut '+$f.Name)}
            }
        }
    }finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)}
    foreach($base in $script:UserRegBases){foreach($suffix in @('Software/Microsoft/Windows/CurrentVersion/Run','Software/Microsoft/Windows/CurrentVersion/RunOnce')){
        $path=Join-Path $base $suffix;if(-not(Test-Path -LiteralPath $path)){continue};$key=Get-Item -LiteralPath $path
        foreach($name in $key.GetValueNames()){
            if($name -notmatch '^(?:whispr|TorVPN)'){continue};$tokens=@(Split-WindowsCommandLine ([string]$key.GetValue($name)))
            if($tokens.Count -and (Is-AppPath $tokens[0])){Backup-Registry $path;Remove-ItemProperty -LiteralPath $path -Name $name -Force;Record 'REMOVED' ('Startup value '+$name)}
        }
    }}
}
function Initialize-Paths {
    $script:Data=[Environment]::GetFolderPath('CommonApplicationData')
    foreach($pf in @([Environment]::GetFolderPath('ProgramFiles'),[Environment]::GetFolderPath('ProgramFilesX86'))|Select-Object -Unique){if($pf){foreach($n in @('whispr Hybrid VPN','whispr VPN','TorVPN')){$script:AppRoots+=Join-Path $pf $n}}}
    foreach($n in @('whispr-hybrid','whispr-vpn-desktop','whispr-hybrid-msi','whispr-vpn-setup','torvpn')){$script:StateRoots+=Join-Path $script:Data $n}
    $script:Roots=@($script:AppRoots)+@($script:StateRoots)
    $script:InstallerBases=@('Registry::HKEY_LOCAL_MACHINE/SOFTWARE/Classes/Installer','Registry::HKEY_LOCAL_MACHINE/SOFTWARE/WOW6432Node/Classes/Installer')
    $script:UninstallBases=@('Registry::HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows/CurrentVersion/Uninstall','Registry::HKEY_LOCAL_MACHINE/SOFTWARE/WOW6432Node/Microsoft/Windows/CurrentVersion/Uninstall')
    $script:UserRegBases=@('Registry::HKEY_LOCAL_MACHINE')
    foreach($k in Get-ChildItem 'Registry::HKEY_USERS'){
        if($k.PSChildName -match '^S-1-5-21-[0-9-]+$'){
            $base='Registry::HKEY_USERS/'+$k.PSChildName;$script:UserRegBases+=$base;$script:InstallerBases+=Join-Path $base 'Software/Microsoft/Installer';$script:UninstallBases+=Join-Path $base 'Software/Microsoft/Windows/CurrentVersion/Uninstall'
            $script:InstallerBases+=Join-Path $base 'Software/Classes/Installer'
        }
    }
    $script:ShortcutDirs=@([Environment]::GetFolderPath('CommonPrograms'),[Environment]::GetFolderPath('CommonStartup'))
    foreach($profile in @(Get-CimInstance Win32_UserProfile -OperationTimeoutSec 15|Where-Object {-not $_.Special -and $_.LocalPath})){
        foreach($rel in @('AppData/Roaming/Microsoft/Windows/Start Menu/Programs','AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup','Desktop')){$script:ShortcutDirs+=Join-Path $profile.LocalPath $rel}
    }
}
function New-Report {
    $base=Join-Path ([Environment]::GetFolderPath('CommonDocuments')) 'whispr-VPN-Recovery'
    if(Exists $base){Assert-NoAncestorLinks $base}else{[void][IO.Directory]::CreateDirectory($base)};Protect-Node (Get-Item -LiteralPath $base)
    $script:Report=Join-Path $base ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8))
    [void][IO.Directory]::CreateDirectory($script:Report);Protect-Node (Get-Item -LiteralPath $script:Report)
}
function Save-Report([string]$Result){
    [pscustomobject]@{Product='whispr-vpn-hard-reset';Version='1.0.0';Result=$Result;RebootRequired=$script:Reboot;Failures=@($script:Failures.ToArray());Events=@($script:Events.ToArray());RemainingRoots=@($script:Roots|Where-Object {Exists $_});ProductCodes=@($script:Codes)}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $script:Report 'result.json') -Encoding UTF8
}
function Restore-DeviceIdentity {
    $base=Join-Path ([Environment]::GetFolderPath('CommonDocuments')) 'whispr-VPN-Recovery';Assert-NoAncestorLinks $base
    $choices=@(Get-ChildItem -LiteralPath $base -Directory|Sort-Object Name -Descending|Where-Object {(Exists (Join-Path $_.FullName 'identity/device-key.json')) -or (Exists (Join-Path $_.FullName 'alternate-identities'))})
    if(-not $choices.Count){throw 'No saved device identity is available'}
    if(-not(Exists (Join-Path $choices[0].FullName 'identity/device-key.json'))){throw 'The latest recovery contains multiple distinct identities. They are preserved under alternate-identities in the report folder; automatic restoration will not pick an older key.'}
    $source=Join-Path $choices[0].FullName 'identity';Assert-NoAncestorLinks $source
    $key=Read-Record (Join-Path $source 'device-key.json')
    foreach($field in @('PrivateKey','PublicKey')){if([string](Field $key $field) -notmatch '^[A-Za-z0-9+/]{43}=$'){throw 'The saved device key is malformed. Its backup was retained; no state was restored.'}}
    $state=Join-Path $script:Data 'whispr-hybrid'
    if(Exists $state){throw 'State already exists. Restore identity immediately after the reset and before installing; existing state was not overwritten.'}
    [void][IO.Directory]::CreateDirectory($state);Protect-Node (Get-Item -LiteralPath $state)
    foreach($f in Get-ChildItem -LiteralPath $source -Force){if(Is-Link $f){throw 'Linked identity backup rejected'};Copy-Item -LiteralPath $f.FullName -Destination $state -Recurse -Force}
    Protect-Tree $state;[IO.File]::WriteAllText((Join-Path $state 'install-owner.txt'),'whispr-hybrid-schema-1')
    Write-Host 'Original device key and saved exit profiles restored. Now install the MSI.' -ForegroundColor Green
}
function Schedule-BootCleanup {
    $work=Join-Path $script:Data 'whispr-vpn-rescue-once';if(Exists $work){Assert-NoAncestorLinks $work}else{[void][IO.Directory]::CreateDirectory($work)};Protect-Node (Get-Item -LiteralPath $work)
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $work 'Reset-WhisprVPN.ps1') -Force
    [IO.File]::WriteAllText((Join-Path $work 'scheduled-at.txt'),[DateTime]::UtcNow.ToString('o'))
    [void][IO.Directory]::CreateDirectory((Join-Path $work 'tools'));Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'tools/whispr-vpn-guard.exe') -Destination (Join-Path $work 'tools/whispr-vpn-guard.exe') -Force;Protect-Tree $work
    $s=New-Object -ComObject Schedule.Service;$s.Connect();$d=$s.NewTask(0)
    try{$existing=$s.GetFolder('\').GetTask('whispr-VPN-Recovery-Once');if($existing.Definition.RegistrationInfo.Source -cne 'whispr-vpn-hard-reset-once-v1'){throw 'The recovery task name is already in use by an unverified task.'}}catch{if($_.Exception.Message -like '*unverified task*'){throw}}
    $d.RegistrationInfo.Source='whispr-vpn-hard-reset-once-v1';$d.Principal.UserId='S-1-5-18';$d.Principal.LogonType=5;$d.Principal.RunLevel=1
    $d.Settings.Enabled=$true;$d.Settings.StartWhenAvailable=$true;$d.Settings.DisallowStartIfOnBatteries=$false;$d.Settings.StopIfGoingOnBatteries=$false;$d.Settings.ExecutionTimeLimit='PT15M';$d.Settings.MultipleInstances=2
    $trigger=$d.Triggers.Create(8);$trigger.Delay='PT20S';$a=$d.Actions.Create(0);$a.Path="$env:SystemRoot/System32/WindowsPowerShell/v1.0/powershell.exe";$a.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+(Quote-Argument (Join-Path $work 'Reset-WhisprVPN.ps1'))+' -BootPhase';$a.WorkingDirectory="$env:SystemRoot/System32"
    [void]$s.GetFolder('\').RegisterTaskDefinition('whispr-VPN-Recovery-Once',$d,6,'S-1-5-18',$null,5,'O:BAG:BAD:P(A;;GA;;;SY)(A;;GA;;;BA)')
    Record 'REBOOT' 'Locked remnants will be retried once as SYSTEM at the next Windows startup. No automatic reboot was requested.'
}
if($FunctionsOnly){return}
$exitCode=1;$msiLock=$null;$ownsMsiLock=$false;$recoveryLock=$null;$ownsRecoveryLock=$false
try{
    if([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or -not [Environment]::Is64BitProcess){throw 'Run this tool in 64-bit Windows PowerShell.'}
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    if(-not([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
        $flags=if($AuditOnly){' -AuditOnly'}elseif($RestoreIdentity){' -RestoreIdentity'}else{''}
        $p=Start-Process -FilePath "$env:SystemRoot/System32/WindowsPowerShell/v1.0/powershell.exe" -Verb RunAs -ArgumentList ('-NoLogo -NoProfile -ExecutionPolicy Bypass -File '+(Quote-Argument $PSCommandPath)+$flags) -PassThru -Wait
        exit $p.ExitCode
    }
    $recoveryLock=[Threading.Mutex]::new($false,'Global\whisprVPNHardReset100')
    try{$ownsRecoveryLock=$recoveryLock.WaitOne(0)}catch [Threading.AbandonedMutexException]{$ownsRecoveryLock=$true}
    if(-not $ownsRecoveryLock){throw 'Another whispr recovery pass is running. Wait for it to finish.'}
    Initialize-Paths
    if($RestoreIdentity){
        $s=New-Object -ComObject Schedule.Service;$s.Connect();$pending=$false
        try{$task=$s.GetFolder('\').GetTask('whispr-VPN-Recovery-Once');$pending=$task.Definition.RegistrationInfo.Source -ceq 'whispr-vpn-hard-reset-once-v1'}catch{}
        if($pending){throw 'A recovery retry is pending. Restart Windows and wait for startup cleanup before restoring identity.'}
        Restore-DeviceIdentity;exit 0
    }
    New-Report;Discover-Products
    if($BootPhase){
        $stamp=Join-Path $PSScriptRoot 'scheduled-at.txt';$launcher=Join-Path ([Environment]::GetFolderPath('ProgramFiles')) 'whispr Hybrid VPN/whispr.exe'
        if((Exists $stamp) -and (Exists $launcher)){
            $scheduled=[DateTime]::Parse((Get-Content -LiteralPath $stamp -Raw),[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)
            if((Get-Item -LiteralPath $launcher).CreationTimeUtc -gt $scheduled.ToUniversalTime()){
                $s=New-Object -ComObject Schedule.Service;$s.Connect();$task=$s.GetFolder('\').GetTask('whispr-VPN-Recovery-Once')
                if($task.Definition.RegistrationInfo.Source -ceq 'whispr-vpn-hard-reset-once-v1'){$s.GetFolder('\').DeleteTask('whispr-VPN-Recovery-Once',0)}
                Record 'SKIPPED' 'A client launcher was created after this retry was scheduled. Automatic cleanup was cancelled to protect the newer installation.'
                Save-Report 'skipped-newer-installation';exit 2
            }
        }
    }
    Record 'MODE' $(if($AuditOnly){'Read-only inventory. No installation/network state will be removed.'}else{'HARD RESET: disconnecting whispr and removing its local installations, registrations and saved state.'})
    foreach($r in $script:Roots){if(Exists $r){Record 'FOUND' $r}}
    if($AuditOnly){
        Clean-Tasks -ReadOnly;Clean-Services -ReadOnly
        foreach($p in @(Process-List)){Record 'FOUND' ('Process '+$p.ProcessId+' '+$p.ExecutablePath)};foreach($a in @(Owned-Adapters)){Record 'FOUND' ('Adapter '+$a.Name)}
        foreach($code in $script:Codes){
            foreach($base in $script:UninstallBases){if(Test-Path -LiteralPath (Join-Path $base $code)){Record 'FOUND' ('MSI uninstall registration '+$code)}}
            foreach($base in $script:InstallerBases){if(Test-Path -LiteralPath (Join-Path $base ('Products/'+(Pack-Code $code)))){Record 'FOUND' ('MSI internal registration '+$code)}}
        }
        foreach($r in @(Firewall-Rules|Where-Object {$_.Group -in @('TORVPN','whispr Hybrid VPN','whispr-HybridVPN')})){Record 'FOUND' ('Owned firewall rule '+$r.Name)}
        Save-Report 'audit';Record 'RESULT' 'Read-only inventory complete. Any FOUND entries remain present; this is not a clean-install certification.';$exitCode=0
    }
    else{
        $msiLock=[Threading.Mutex]::new($false,'Global\_MSIExecute')
        try{$ownsMsiLock=$msiLock.WaitOne(0)}catch [Threading.AbandonedMutexException]{$ownsMsiLock=$true}
        if(-not $ownsMsiLock){throw 'Windows Installer is busy. Finish or close the active installation before running this reset.'}
        $msiLock.ReleaseMutex();$ownsMsiLock=$false
        Attempt 'Stop/remove owned scheduled tasks' {Clean-Tasks}
        Attempt 'Stop/remove owned services' {Clean-Services}
        Attempt 'Stop verified resident processes' {Stop-OwnedProcesses}
        Attempt 'Back up device identity' {Save-Identity}
        if($script:Failures -contains 'Back up device identity'){throw 'Identity backup did not complete. Saved application state was retained.'}
        Attempt 'Recover owned Rust WFP provider' {Recover-Guard}
        foreach($r in $script:StateRoots){Attempt ('Unlock '+$r) {if(Exists $r){Protect-Tree $r}}}
        Attempt 'Restore legacy firewall journal' {Recover-LegacyFirewall}
        Attempt 'Restore legacy audit policy' {Recover-LegacyAudit}
        Attempt 'Remove owned routes and adapters' {Clean-Adapters}
        Attempt 'Remove owned firewall/DNS rules' {Clean-FirewallDNS}
        Attempt 'Remove old shortcuts and startup values' {Clean-ShortcutsAndStartup}
        # Journals that could not be restored are retained. Other cleanup stages continue independently.
        $keepState=($script:Failures -contains 'Restore legacy firewall journal' -or $script:Failures -contains 'Restore legacy audit policy' -or $script:Failures -contains 'Remove owned routes and adapters')
        foreach($r in $script:Roots){if($keepState -and (Canonical $r) -ieq (Canonical (Join-Path $script:Data 'torvpn'))){continue};Attempt ('Delete '+$r) {Delete-Tree $r}}
        Try-NormalRemoval
        try{$ownsMsiLock=$msiLock.WaitOne(0)}catch [Threading.AbandonedMutexException]{$ownsMsiLock=$true}
        if(-not $ownsMsiLock){throw 'Windows Installer is still executing; orphan registration edits were not attempted.'}
        Attempt 'Remove exact whispr MSI/orphan registrations' {Clean-InstallerRegistration}
        foreach($r in $script:AppRoots){Attempt ('Final delete '+$r) {Delete-Tree $r}}
        Attempt 'Final verified process stop' {Stop-OwnedProcesses}
        Attempt 'Final WFP verification' {Recover-Guard}
        $left=@($script:Roots|Where-Object {Exists $_})
        $tasks=New-Object -ComObject Schedule.Service;$tasks.Connect();$remainingTasks=@(Task-List ($tasks.GetFolder('\')))
        $remainingProcesses=@(Process-List);$remainingAdapters=@(Owned-Adapters);$remainingServices=@(Service-List)
        if($left.Count -or $remainingTasks.Count -or $remainingProcesses.Count -or $remainingAdapters.Count -or $remainingServices.Count){$script:Reboot=$true;Record 'REMAINING' ('Folders='+$left.Count+' tasks='+$remainingTasks.Count+' processes='+$remainingProcesses.Count+' adapters='+$remainingAdapters.Count+' services='+$remainingServices.Count)}
        if($BootPhase){
            $s=New-Object -ComObject Schedule.Service;$s.Connect();$t=$s.GetFolder('\').GetTask('whispr-VPN-Recovery-Once');if($t.Definition.RegistrationInfo.Source -ceq 'whispr-vpn-hard-reset-once-v1'){$s.GetFolder('\').DeleteTask('whispr-VPN-Recovery-Once',0)}
            $work=Join-Path $script:Data 'whispr-vpn-rescue-once'
            if((Canonical $PSScriptRoot) -ieq (Canonical $work)){$script:Roots+=$work;Attempt 'Remove one-shot recovery working files' {Delete-Tree $work}}
        }
        elseif($script:Reboot -or $script:Failures.Count){$script:Reboot=$true;Schedule-BootCleanup}
        if($script:Reboot -or $script:Failures.Count){Save-Report 'attention-required';$exitCode=2;Record 'RESULT' 'Cleanup made progress but is not certified clean. Read result.json; reboot once if requested, then run Audit.'}
        else{Save-Report 'clean';$exitCode=0;Record 'RESULT' 'Known whispr VPN installation objects removed. Ready for a clean MSI installation.'}
    }
}catch{if($script:Report){Record 'FATAL' $_.Exception.Message;Save-Report 'failed'}else{Write-Host $_.Exception.Message -ForegroundColor Red};$exitCode=1}
finally{
    if($ownsMsiLock -and $msiLock){$msiLock.ReleaseMutex()};if($msiLock){$msiLock.Dispose()}
    if($ownsRecoveryLock -and $recoveryLock){$recoveryLock.ReleaseMutex()};if($recoveryLock){$recoveryLock.Dispose()}
    if($script:Report){Write-Host ('Report and protected identity backup: '+$script:Report) -ForegroundColor Cyan}
}
exit $exitCode
