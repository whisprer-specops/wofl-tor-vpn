# Source cleanup only — no replacement installer

This archive is NOT the requested complete MSI. It contains the full existing VPN source with only the capture-specific reference cleanup described below. No installer, process-cleanup or uninstall implementation has been replaced. Do not run an older installer on the assumption that this source cleanup repaired it.

## Exact changes

1. Removed one capture-SDK explanatory sentence from the project README.
2. Replaced the two project-specific SDK directory strings in `tests/Test-AutomaticSetup.ps1` with the same neutral nonexistent compiler directory, retaining the invalid-environment/no-runtime-compilation regression test.

The other 187 source-package files are byte-identical to the supplied 1.0.3 source. No capture implementation or capture dependency was found to remove. Windows API bindings, packet routing, Tor/WireGuard configuration, private-state handling, process ownership checks, third-party notices and existing functionality were not removed. The unchanged third-party notice's `wpcapi.idl` filename is unrelated to a packet-capture dependency and has been retained.

## Verification actually performed

- Byte comparison: exactly the two intended files changed; 187 unchanged.
- Text scan: no exact capture-library/project tokens remain in the cleaned source tree.
- All 78 PowerShell files parsed successfully in Linux PowerShell 7.6.9.
- The existing precompiled helper loaded while runtime Add-Type compilation was forbidden and generic invalid compiler search directories were present. Those variable values remained unchanged.
- Archive contents checked against staged bytes.

The source-cleanup verifier is included as `Verify-SourceCleanup.ps1`. Run with PowerShell 7.2 or newer; the verified host was 7.6.9 on Linux:

```powershell
pwsh -NoLogo -NoProfile -File .\Verify-SourceCleanup.ps1
```

This verifier changes compiler path variables only in its own process; it does not write persistent environment settings or change networking.

## Requested MSI remains unfinished

The existing package installs desktop controls; the actual client and private state are outside MSI ownership. Its maintenance UI therefore does not implement the requested full-product lifecycle. A complete replacement needs implementation and actual Windows 11 testing of:

- Existing/partial install inventory and recovery using valid product ownership.
- Automatic scoped shutdown of owned processes and restart sources.
- Install/upgrade/repair rollback, retained keys/profiles on repair, and usable networking after failure/cancellation.
- Five endpoint selection and actual connection verification before green.
- Full local removal of app-owned tasks, processes, network objects, application state, files and registration through the same product UI.

For this source package, no replacement MSI was built and no Windows install/upgrade/repair/uninstall/connection acceptance run was performed. Linux parse/helper checks cannot establish these behaviors. This session has no accessible Windows VM/runner. That is an outstanding environment requirement, not a claim that the implementation is ready and merely lacks a label.

Windows-owned logs/history and its own installer bookkeeping are outside the application's uninstall ownership. "Complete uninstall" must mean removing app-owned live components/state, not deleting unrelated Windows records or shared dependencies. Uninstalling this local app should not remove shared VPS exit services or other users' peers.

## Build/version caution

The original source directory/version is retained for comparison, not issued as a new release. The original build files still name desktop MSI 1.0.2. The original 1.0.3 bootstrap uses a frozen MSI 1.0.2. A future changed MSI must get a new release/ProductCode/version and cannot be redistributed as though it were the original frozen MSI. See source/build notes and the existing handover for original rebuild inputs.

The most important remaining risk is the unimplemented and unverified Windows installation lifecycle. This source cleanup does not remedy that risk.
