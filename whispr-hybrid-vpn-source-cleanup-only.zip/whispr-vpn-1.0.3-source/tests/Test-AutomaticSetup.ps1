#requires -Version 7.2
$ErrorActionPreference='Stop'
$r=Split-Path $PSScriptRoot -Parent
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('whispr-auto-setup-'+[guid]::NewGuid().ToString('N'))
$env:ProgramFiles=Join-Path $fixture 'programs';$env:ProgramData=Join-Path $fixture 'data'
$ExpectedNativeHash=(Get-FileHash "$r/setup/bin/Whispr.Setup.Native.dll").Hash
. "$r/setup/Setup.ps1" -LibraryOnly -PackageRoot "$r/setup/bin" -ExpectedNativeHash $ExpectedNativeHash
$env:LIB='C:\__whispr_missing_compiler_sdk__\lib\x64';$env:LIBPATH='C:\nonexistent-sdk\lib'
function Add-Type {throw 'Runtime compilation is forbidden in setup'}
function Check([bool]$Condition,[string]$Why){if(-not $Condition){throw $Why}}
function Reject([scriptblock]$Action,[string]$Why){try{& $Action|Out-Null}catch{return};throw $Why}
New-Item -ItemType Directory -Path $fixture -Force|Out-Null
try{
    $t=$null;$e=$null;[void][Management.Automation.Language.Parser]::ParseFile("$r/setup/Setup.ps1",[ref]$t,[ref]$e);Check ($e.Count -eq 0) 'PowerShell syntax errors'
    Add-SetupNative # Load the actual precompiled .NET Framework helper; no compiler invocation.
    Check ($env:LIB -ceq 'C:\__whispr_missing_compiler_sdk__\lib\x64' -and $env:LIBPATH -ceq 'C:\nonexistent-sdk\lib') 'Setup modified inherited compiler environment'
    $savedNativeHash=$ExpectedNativeHash;$ExpectedNativeHash='0'*64
    Reject {Add-SetupNative} 'A wrong precompiled helper hash was accepted'
    $ExpectedNativeHash=$savedNativeHash
    $assembly=[WhisprSetupNative103].Assembly
    Check ($assembly.GetReferencedAssemblies().Count -eq 1 -and $assembly.GetReferencedAssemblies()[0].Name -ceq 'mscorlib') 'Helper targets the wrong CLR'
    Check ($assembly.ImageRuntimeVersion -ceq 'v4.0.30319') 'Helper runtime incompatible with Windows PowerShell'
    Check (-not ([IO.File]::ReadAllText("$r/setup/Setup.ps1")).Contains('Add-Type')) 'A runtime compilation path remains in setup' 
    $failureLog=Join-Path $fixture 'fixture-msi.log'
    [IO.File]::WriteAllText($failureLog,"MSI info`nwhispr VPN preflight: fixture reason`n")
    Check ((Get-MsiFailureSummary $failureLog).Contains('fixture reason')) 'MSI reason was not extracted'
    $wanted=Join-Path $script:Core 'Tray.ps1'
    Check (Test-ScriptArguments @('-NoProfile','-STA','-File',$wanted) @($wanted)) 'Owned script not recognised'
    Check (Test-ScriptArguments @('-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$wanted) @($wanted)) 'Standard task switches not recognised'
    foreach($tokens in @(@('-Command',('Write-Host -File "'+$wanted+'"')),@('-EncodedCommand','aQBlAHgA'),@('-File',($wanted+'.bak')),@('-NoProfile','-File','/another/Tray.ps1'),@('-File'))){Check (-not (Test-ScriptArguments $tokens @($wanted))) 'Unsafe command tokens accepted'}
    function Split-CommandLine([string]$Command){return $script:FakeTokens}
    $script:FakeTokens=@('/system/pwsh.exe','-NoProfile','-File',$wanted)
    $own=[pscustomobject]@{ProcessId=10001;ExecutablePath='/system/pwsh.exe';CommandLine='fixture';CreationDate=[DateTime]::UtcNow}
    Check (Test-OwnProcess $own) 'System PowerShell running exact whispr script missed'
    $script:FakeTokens=@('/system/pwsh.exe','-Command','Write-Host -File "'+$wanted+'"')
    Check (-not (Test-OwnProcess $own)) 'PowerShell -Command false positive'
    foreach($name in @('explorer.exe','svchost.exe','WindowsTerminal.exe','lsass.exe','services.exe','csrss.exe','cmd.exe')){
        $p=[pscustomobject]@{ProcessId=10002;ExecutablePath=(Join-Path $script:Core $name);CommandLine='fixture';CreationDate=[DateTime]::UtcNow}
        Check (-not (Test-OwnProcess $p)) ('Critical/unrelated process selected: '+$name)
    }
    $tor=[pscustomobject]@{ProcessId=10003;ExecutablePath=(Join-Path $script:Core 'bin\tor\tor.exe');CommandLine='';CreationDate=[DateTime]::UtcNow}
    Check (Test-OwnProcess $tor) 'Exact owned Tor missed'
    $other=[pscustomobject]@{ProcessId=10004;ExecutablePath='/other/Tor Browser/tor.exe';CommandLine='';CreationDate=[DateTime]::UtcNow}
    Check (-not (Test-OwnProcess $other)) 'Tor Browser selected'
    $other.ExecutablePath=(Join-Path ($script:Core+'-other') 'bin\tor\tor.exe');Check (-not (Test-OwnProcess $other)) 'Directory-prefix collision selected'
    $script:ProcessRecords=@($tor,$other);$script:Stopped=New-Object 'Collections.Generic.List[int]'
    $binaryFolder=Join-Path $script:Core 'bin/tor';New-Item -ItemType Directory $binaryFolder -Force|Out-Null
    $binary=Join-Path $binaryFolder 'tor.exe';[IO.File]::WriteAllText($binary,'owned fixture')
    Assert-OwnedExecutable $binary
    if(-not $IsWindows){
        $external=Join-Path $fixture 'other-app';New-Item -ItemType Directory $external|Out-Null
        [IO.File]::WriteAllText((Join-Path $external 'tor.exe'),'unrelated fixture')
        $link=Join-Path $script:Core 'linked-bin';New-Item -ItemType SymbolicLink -Path $link -Target $external|Out-Null
        Reject {Assert-OwnedExecutable (Join-Path $link 'tor.exe')} 'A linked executable path was accepted'
        Remove-Item -LiteralPath $link -Force
    }
    function Assert-OwnedExecutable([string]$Path) {} # Windows path/ACL boundary for process fixtures
    function Get-ProcessSnapshot {return @($script:ProcessRecords)}
    function Stop-VerifiedProcess($Record){$script:Stopped.Add([int]$Record.ProcessId);$script:ProcessRecords=@($script:ProcessRecords|Where-Object ProcessId -ne $Record.ProcessId);return $true}
    Stop-OwnProcesses
    Check ($script:Stopped.Count -eq 1 -and $script:Stopped[0] -eq 10003) 'Quiesce selected another process'
    $one='<Task xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"><Settings><Enabled>true</Enabled></Settings><Actions><Exec><Command>pwsh.exe</Command></Exec></Actions></Task>'
    Check ((Task-Fingerprint $one) -ceq (Task-Fingerprint ($one.Replace('true','false')))) 'Enabled setting changes task fingerprint'
    Check ((Task-Fingerprint $one) -cne (Task-Fingerprint ($one.Replace('pwsh.exe','other.exe')))) 'Changed action keeps task fingerprint'
    $script:TaskName='whispr-HybridVPN-Autostart-S-1-5-21-123-456-789-1001'
    $action=[pscustomobject]@{Type=0;Path='/system/pwsh.exe';Arguments='fixture';WorkingDirectory=$script:Core}
    $actions=[pscustomobject]@{Count=1;Value=$action};$actions|Add-Member ScriptMethod Item {param($Index);if($Index -ne 1){throw 'Unexpected index'};return $this.Value}
    $definition=[pscustomobject]@{RegistrationInfo=[pscustomobject]@{Source='whispr-hybrid-autostart-v1'};Principal=[pscustomobject]@{UserId='S-1-5-21-123-456-789-1001'};Actions=$actions}
    $script:FakeTokens=@('pwsh.exe','-NoProfile','-File',$wanted)
    Check (Test-TaskDefinition $script:TaskName $definition) 'Owned task rejected'
    $definition.RegistrationInfo.Source='another-product';Reject {Test-TaskDefinition $script:TaskName $definition} 'Unrecognised task source accepted';$definition.RegistrationInfo.Source='whispr-hybrid-autostart-v1'
    $definition.Principal.UserId='S-1-5-21-999-1001';Reject {Test-TaskDefinition $script:TaskName $definition} 'Another principal accepted';$definition.Principal.UserId='S-1-5-21-123-456-789-1001'
    $script:FakeTask=[pscustomobject]@{Enabled=$true;Definition=$definition;Template=$one;Path=('\'+$script:TaskName)}
    $script:FakeTask|Add-Member ScriptProperty Xml {return $this.Template.Replace('<Enabled>true</Enabled>',('<Enabled>'+([string]$this.Enabled).ToLowerInvariant()+'</Enabled>'))}
    $script:FakeTask|Add-Member ScriptMethod Stop {param($Flags);return}
    $folder=[pscustomobject]@{};$folder|Add-Member ScriptMethod GetTask {param($Name);if($Name -cne $script:TaskName){throw 'Unexpected task name'};return $script:FakeTask}
    $script:FakeFolder=$folder
    $taskService=[pscustomobject]@{};$taskService|Add-Member ScriptMethod GetFolder {param($Path);if($Path -cne '\'){throw 'Unexpected task folder'};return $script:FakeFolder}
    $script:TaskService=$taskService
    function Connect-TaskScheduler {return $script:TaskService}
    function Get-OwnTasks($Folder){return [pscustomobject]@{Path=$script:FakeTask.Path;Enabled=$script:FakeTask.Enabled;Fingerprint=(Task-Fingerprint $script:FakeTask.Xml);Task=$script:FakeTask}}
    function Assert-SetupAdministrator {}
    function Assert-Directory {param($Path,[switch]$Optional);if(-not $Optional -and -not (Test-Path -LiteralPath $Path -PathType Container)){throw 'Missing fixture directory'}}
    function Get-OwnServices {return @()}
    function Stop-OwnServices($Records) {}
    function Restore-Services($Records,[bool]$Successful) {}
    function Enter-SetupLock([string]$Name){$script:Events.Add('Lock '+$Name)}
    function Remove-OwnTunnel {$script:Events.Add('Tunnel')}
    function Invoke-Guard([string]$Command){$script:Events.Add('Guard '+$Command);if($Command -eq 'status'){return 'DISARMED'}}
    function Stop-OwnProcesses {if($script:FailStop){throw 'Fixture stop failure'};$script:Events.Add('Stop')}
    function Invoke-DesktopMsi([string]$Msi,[string]$Log){Check (-not $script:FakeTask.Enabled) 'Startup task still enabled during MSI';$script:Events.Add('MSI');return $script:MsiResult}
    $PackageRoot=Join-Path $fixture 'package';New-Item -ItemType Directory $PackageRoot|Out-Null
    Copy-Item -LiteralPath "$r/dist/whispr-vpn-1.0.2-x64.msi" -Destination $PackageRoot
    Copy-Item -LiteralPath "$r/packs/friend/app/bin/whispr-vpn-guard.exe" -Destination $PackageRoot
    Copy-Item -LiteralPath "$r/setup/bin/Whispr.Setup.Native.dll" -Destination $PackageRoot
    $ExpectedMsiHash=(Get-FileHash (Join-Path $PackageRoot 'whispr-vpn-1.0.2-x64.msi')).Hash
    New-Item -ItemType Directory $script:State -Force|Out-Null
    $keyPath=Join-Path $script:State 'device-key.json';[IO.File]::WriteAllText($keyPath,'PRIVATE_IDENTITY_SENTINEL')
    $profile=Join-Path $script:State 'peer.json';[IO.File]::WriteAllText($profile,'PUBLIC_PROFILE_SENTINEL')
    $privateHash=(Get-FileHash $keyPath).Hash;$profileHash=(Get-FileHash $profile).Hash
    $tx=Join-Path $fixture 'transactions';New-Item -ItemType Directory $tx|Out-Null
    foreach($case in @('success','cancel','msi-failed','stop-failed')){
        $JournalRoot=Join-Path $tx ([guid]::NewGuid().ToString('N'));New-Item -ItemType Directory $JournalRoot|Out-Null
        Save-Json @{State='verified-session';TunnelGuid='{fixture}';OwnerPid=10003} (Join-Path $script:State 'session.json')
        $script:FakeTask.Enabled=$true;$script:Events=New-Object 'Collections.Generic.List[string]';$script:FailStop=$case -eq 'stop-failed'
        $script:MsiResult=switch($case){'success'{0}'cancel'{1602}'msi-failed'{1603}default{0}}
        if($case -eq 'success'){Check ((Invoke-Setup) -eq 0) 'Successful flow did not finish'}else{Reject {Invoke-Setup} ('Failure was not propagated: '+$case)}
        Check $script:FakeTask.Enabled ('Startup preference lost: '+$case)
        Check ((Get-FileHash $keyPath).Hash -ceq $privateHash -and (Get-FileHash $profile).Hash -ceq $profileHash) ('Device identity/profile changed: '+$case)
        $journal=Read-Json (Join-Path $JournalRoot 'journal.json');Check ($journal.Phase -in @('complete','failed-settings-restored')) 'Recovery phase not recorded'
        if($case -ne 'stop-failed'){
            Check ($script:Events.IndexOf('Stop') -lt $script:Events.IndexOf('MSI')) 'MSI launched before process cleanup'
            Check ($script:Events.IndexOf('Guard status') -lt $script:Events.IndexOf('MSI')) 'MSI launched before guard verification'
            Check ((Read-Json (Join-Path $script:State 'session.json')).State -ceq 'disconnected') 'Stale green session retained'
            Check (Test-Path (Join-Path $JournalRoot 'session-before.json')) 'Original session backup missing'
        }else{Check ('MSI' -notin $script:Events) 'MSI ran after cleanup failure'}
    }
    $JournalRoot=Join-Path $tx ([guid]::NewGuid().ToString('N'));New-Item -ItemType Directory $JournalRoot|Out-Null
    $old=Join-Path $tx ([guid]::NewGuid().ToString('N'));New-Item -ItemType Directory $old|Out-Null
    Save-Json @{Product='whispr-vpn-setup';Schema=1;Version='1.0.2';Phase='installing';Tasks=@(@{Path=$script:FakeTask.Path;Enabled=$true;Fingerprint=(Task-Fingerprint $script:FakeTask.Xml)});Services=@()} (Join-Path $old 'journal.json')
    $script:FakeTask.Enabled=$false;Resume-InterruptedJournals $script:TaskService
    Check $script:FakeTask.Enabled 'Interrupted setup did not restore task setting'
    Check ((Read-Json (Join-Path $old 'journal.json')).Phase -ceq 'interrupted-settings-restored') 'Interrupted journal was not completed'
    'PASS: actual setup script parsed and precompiled NET Framework helper loaded with invalid LIB/LIBPATH and Add-Type forbidden; exact process/task ownership; critical-process rejection; task fingerprint; full success/cancel/MSI-failure/stop-failure workflows; actual journal/session backups and byte-identical key/profile preservation; interrupted-settings recovery. Windows process/SCM/COM/MSI/adapter boundaries mocked.'
}finally{Remove-Item -LiteralPath $fixture -Recurse -Force -ErrorAction SilentlyContinue}
