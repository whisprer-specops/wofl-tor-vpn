#requires -Version 7.2
$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot 'whispr-vpn-1.0.3-source'
$count=0
foreach($file in Get-ChildItem -LiteralPath $root -Recurse -Filter '*.ps1' -File){
    $tokens=$null;$errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    if($errors.Count){throw (($errors|ForEach-Object {$_.ToString()}) -join "`n")}
    $count++
}
$env:ProgramFiles=Join-Path ([IO.Path]::GetTempPath()) 'whispr-cleanup-parse-programs'
$env:ProgramData=Join-Path ([IO.Path]::GetTempPath()) 'whispr-cleanup-parse-data'
$ExpectedNativeHash=(Get-FileHash (Join-Path $root 'setup/bin/Whispr.Setup.Native.dll')).Hash
. (Join-Path $root 'setup/Setup.ps1') -LibraryOnly -PackageRoot (Join-Path $root 'setup/bin') -ExpectedNativeHash $ExpectedNativeHash
$env:LIB='C:\__whispr_missing_compiler_sdk__\lib\x64'
$env:LIBPATH='C:\nonexistent-sdk\lib'
function Add-Type {throw 'Runtime compilation is forbidden during this verification'}
Add-SetupNative
if($env:LIB -cne 'C:\__whispr_missing_compiler_sdk__\lib\x64' -or $env:LIBPATH -cne 'C:\nonexistent-sdk\lib'){throw 'Compiler environment changed'}
$assembly=[WhisprSetupNative103].Assembly
if($assembly.ImageRuntimeVersion -cne 'v4.0.30319'){throw 'Unexpected helper runtime metadata'}
if($assembly.GetReferencedAssemblies().Count -ne 1 -or $assembly.GetReferencedAssemblies()[0].Name -cne 'mscorlib'){throw 'Unexpected helper references'}
"PASS: $count PowerShell files parse."
'PASS: existing precompiled helper loads with generic invalid compiler paths and Add-Type forbidden; compiler path values unchanged.'
'LIMIT: Linux PowerShell execution only; no Windows install/process/task/device/network/MSI acceptance test.'
